<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Commercial Listing</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link href="http://cdn.rawgit.com/davidstutz/bootstrap-multiselect/master/dist/css/bootstrap-multiselect.css"
        rel="stylesheet" type="text/css" />
    <script src="http://cdn.rawgit.com/davidstutz/bootstrap-multiselect/master/dist/js/bootstrap-multiselect.js"
        type="text/javascript"></script>
    <script src="toggle.js" type="text/javascript"></script>
	<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<script src="form.js"></script>



<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>

<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">





<link rel="stylesheet" href="assets/css/bootstrap.css">
	  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    
<link rel="stylesheet" href="assets/vendors/simple-datatables/style.css">

    <link rel="stylesheet" href="assets/vendors/perfect-scrollbar/perfect-scrollbar.css">
    <link rel="stylesheet" href="assets/css/app.css">
    <link rel="shortcut icon" href="assets/images/favicon.svg" type="image/x-icon">
<style>
.preview-images-zone {
    width: 100%;
    border: 1px solid #ddd;	
    min-height: 180px;
    /* display: flex; */
    padding: 5px 5px 0px 5px;
    position: relative;
    overflow:auto;
}
.preview-images-zone > .preview-image:first-child {
    height: 185px;
    width: 185px;
    position: relative;
    margin-right: 5px;
}
.preview-images-zone > .preview-image {
    height: 90px;
    width: 90px;
    position: relative;
    margin-right: 5px;
    float: left;
    margin-bottom: 5px;
}
.preview-images-zone > .preview-image > .image-zone {
    width: 100%;
    height: 100%;
}
.preview-images-zone > .preview-image > .image-zone > img {
    width: 100%;
    height: 100%;
}
.preview-images-zone > .preview-image > .tools-edit-image {
    position: absolute;
    z-index: 100;
    color: #fff;
    bottom: 0;
    width: 100%;
    text-align: center;
    margin-bottom: 10px;
    display: none;
}
.preview-images-zone > .preview-image > .image-cancel {
    font-size: 18px;
    position: absolute;
    top: 0;
    right: 0;
    font-weight: bold;
    margin-right: 10px;
    cursor: pointer;
    display: none;
    z-index: 100;
}
.preview-image:hover > .image-zone {
    cursor: move;
    opacity: .5;
}
.preview-image:hover > .tools-edit-image,
.preview-image:hover > .image-cancel {
    display: block;
}
.ui-sortable-helper {
    width: 90px !important;
    height: 90px !important;
}

.container {
    padding-top: -23px;
}
</style>
</head>
<body>
	<div id="app">
        <div id="sidebar" class='active'>
            <div class="sidebar-wrapper active">
    <div class="sidebar-header">
        <img src="assets/images/logo.svg" alt="" srcset="">
    </div>
    <div class="sidebar-menu">
        <ul class="menu">
            
            
                <li class='sidebar-title'>Main Menu</li>
            
            
            
                <li class="sidebar-item  ">
                    <a href="index.html" class='sidebar-link'>
                        <i data-feather="home" width="20"></i> 
                        <span>Dashboard</span>
                    </a>
                    
                </li>

            
            
            
                
				<li class="sidebar-item active ">
                    <a href="{{url('/')}}/blog-table" class='sidebar-link'>
                        <i data-feather="file-plus" width="20"></i> 
                        <span>Blog</span>
                    </a>
                    
                </li>
				<li class="sidebar-item active ">
                    <a href="{{url('/')}}/contact-table" class='sidebar-link'>
                        <i data-feather="file-plus" width="20"></i> 
                        <span>Contact</span>
                    </a>
                    
                </li>
				<li class="sidebar-item active ">
                    <a href="{{url('/')}}/newsletter-table" class='sidebar-link'>
                        <i data-feather="file-plus" width="20"></i> 
                        <span>Newsletter</span>
                    </a>
                    
                </li>

            
            
            
                
            
            
         
        </ul>
    </div>
    <button class="sidebar-toggler btn x"><i data-feather="x"></i></button>
</div>
        </div>
        <div id="main">
            <nav class="navbar navbar-header navbar-expand navbar-light">
                <a class="sidebar-toggler" href="#"><span class="navbar-toggler-icon"></span></a>
                <button class="btn navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                    aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav d-flex align-items-center navbar-light ml-auto">
                        
                        
                        <li class="dropdown">
                            <a href="#" data-toggle="dropdown" class="nav-link dropdown-toggle nav-link-lg nav-link-user">
                                <div class="avatar mr-1">
                                    <img src="assets/images/avatar/avatar-s-1.png" alt="" srcset="">
                                </div>
                                <div class="d-none d-md-block d-lg-inline-block">Hi, Ravali</div>
                            </a>
                            <div class="dropdown-menu dropdown-menu-right">
                                <a class="dropdown-item" href="#"><i data-feather="user"></i> Account</a>
                                <a class="dropdown-item active" href="#"><i data-feather="mail"></i> Messages</a>
                                <a class="dropdown-item" href="#"><i data-feather="settings"></i> Settings</a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="#"><i data-feather="log-out"></i> Logout</a>
                            </div>
                        </li>
                    </ul>
                </div>
            </nav>
<body style="background-color:ActiveBorder">
	
    <form>
        <div class="row" style="text-align:center;">
            <div style="display:inline-block; float:none; text-align:left; margin-right:auto;">
                <div class="input-group">
                    <div class="btn-group" data-toggle="buttons">
                        <label class="btn btn-primary">
                            <input type="radio" name="options" > Sale
                        </label>

                        <label class="btn btn-primary">
                            <input type="radio" name="options"> Rent
                        </label>
                    </div>
                </div>
            </div>
        </div><br>
        <div class="container">
            <div class="row">
                <div class="col-sm-3">
				  <div class="input-group" >
                        <span class="input-group-addon">Property location  </span>
                        <select class="form-control required"   onchange="ShowHideDiv()" required>
                            <option value="" disabled selected>Select location</option>
                            <option value="1">hyd</option>
                            <option value="1">hyd</option>
                            <option value="1">hyd</option>
                            <option value="1">hyd</option>
                            <option value="1">hyd</option>
                            <option value="1">hyd</option>
                            <option value="2">hyd </option>
                        </select>
                    </div>

                </div>
                <div class="col-sm-3">
                    <div class="input-group required">
                        <span class="input-group-addon">City </span>
                         <input type="text" id="cname"  style="height: 33px;"name="cname" >
                    </div>
                </div>
                <div class="col-sm-3">
				 <div class="input-group">
                        <span class="input-group-addon">Property location </span>
                        <select class="form-control required" id="propertytype" onchange="ShowHideDiv()">
                            <option value="" disabled selected>Select location</option>
                            <option value="1">hyd</option>
                            <option value="1">hyd</option>
                            <option value="1">hyd</option>
                            <option value="1">hyd</option>
                            <option value="1">hyd</option>
                            <option value="1">hyd</option>
                            <option value="2">hyd </option>
                        </select>
                    </div>

                </div>
				<div class="col-sm-3">
                    <div class="input-group required">
                        <span class="input-group-addon">LandMark </span>
                         <input type="text" id="lname" name="lname" style="height: 33px;">
                    </div>
                </div>
				
            </div>
        </div><br>

        <div class="container">
            <div class="row">
			<div class="col-sm-3">
			</div>
                <div class="col-sm-6">
                    <div class="input-group">
                        <span class="input-group-addon">Property Type </span>
                        <select class="form-control required" id="propertytype1" onchange="ShowHideDiv()">
                            <option value="" disabled selected>Select Property Type</option>
                            <option value="Villas">Villas</option>
                            <option value="ApartmentFlat">Apartment/Flat</option>
                            <option value="IndependentHouses">IndependentHouses</option>
                            <option value="Plots">Plots</option>
                            <option value="FarmHouse">FarmHouse</option>
                            <option value="FarmLands/Agri Lands">FarmLands/Agri Lands</option>
                            <option value="WareHouses">WareHouses</option>
                        </select>
                    </div>
                </div>
			 <div class="col-sm-3">
			 </div>
			 </div><br>

                


                <div id="propertytypeselect" class=" ApartmentFlat box" style="display:1">
                    <div class="col-sm-4">
                    <div class="input-group">
                        <span class="input-group-addon">Bedrooms</span>
                        <select class="form-control required" id="propertytype" 	onchange="ShowHideDiv()">
                            <option value="" disabled selected>Select Bedrooms</option>
                            
                            <option value="1">01BHK</option>
                            <option value="1">02BHK</option>
                            <option value="1">03BHK</option>
                            <option value="1">04BHK</option>
                            <option value="1">05BHK</option>
                            <option value="1">06BHK</option>
							<option value="2">07BHK</option>
							<option value="2">08BHK</option>
							                            
                        </select>
                    </div>
					
					
                </div>
				                    <div class="col-sm-4">
                    <div class="input-group">
                        <span class="input-group-addon">Balcony</span>
                        <select class="form-control" id="propertytype" onchange="ShowHideDiv()">
                            <option value="" disabled selected>Select Balcony</option>
                           
                            <option value="1">01</option>
                            <option value="1">02</option>
                            <option value="1">03</option>
                            <option value="1">04</option>
                            <option value="1">05</option>
                            <option value="1">06</option>
							<option value="2">07</option>
							<option value="2">08</option>
							                            
                        </select>
                    </div>
					</div>
					 <div class="col-sm-4">
                    <div class="input-group">
                        <span class="input-group-addon">Bathrooms</span>
                        <select class="form-control" id="propertytype" onchange="ShowHideDiv()">
                            <option value="" disabled selected>Select Bathrooms</option>
                            
                            <option value="1">01</option>
                            <option value="1">02</option>
                            <option value="1">03</option>
                            <option value="1">04</option>
                            <option value="1">05</option>
                            <option value="1">06</option>
							<option value="2">07</option>
							<option value="2">08</option>
							                            
                        </select>
                    </div>
					</div>
					

                    <div class="row">
                        <div id="carpet" class="panel-collapse collapse">
                            <div class="col-sm-6">
                                <div class="input-group">
                                    <span class="input-group-addon">Carpet Area</span>
                                    <input type="text" class="form-control">
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="input-group">
                                    <span class="input-group-addon">Plot Area</span>
                                    <input type="text" class="form-control">
                                </div>
                            </div>
                        </div>
                    </div>
                    <br />
					
					
					
                
                <div class="row">
				       
                       <div class="col-sm-4">
                           <div class="row">
							<div class="input-group">
                                <span class="input-group-addon">Total Area</span>
                                <select class="form-control required" id="sel1">
                                    <option value="" disabled selected>Select Total Area</option>
                                    <option>SqYards</option>
                                    <option>Sqft</option>
									
                                </select>
								 
                            </div>
							
							
							</div>
                        </div>
						<div class="col-sm-2" style="padding-right: 127px;padding-left: 0px;">
                                <input type="text" class="form-control">
                        </div>
                        <div class="col-sm-4">
                           <div class="row">
							<div class="input-group">
                                <span class="input-group-addon">BuildUp Area</span>
                                <select class="form-control required" id="sel1">
                                    <option value="" disabled selected>Select BuildUp Area</option>
                                    <option>Sqft</option>
                                    <option>SqYards</option>
									
                                </select>
								 
                            </div>
							
							
							</div>
                        </div>
						<div class="col-sm-2" style="padding-right: 127px;padding-left: 0px;">
                                <input type="text" class="form-control">
                    </div>
					<div class="col-sm-1">
					   </div>
				</div>
				<br>
				<div class="row">
				         
				
						<div class="col-sm-4">
                           <div class="row">
							<div class="input-group">
                                <span class="input-group-addon">Carpet Area</span>
                                <select class="form-control required" id="sel1">
                                    <option value="" disabled selected>Select Carpet Area</option>
                                    <option>Sqft</option>
                                    <option>SqYards</option>
									
                                </select>
								 
                            </div>
							
							
							</div>
                        </div>
						<div class="col-sm-2" style="padding-right: 127px;padding-left: 0px;">
                                <input type="text" class="form-control">
                        </div>
					
                    <br />
				</div><br>
					
					
					
					
					
                    <br />
					                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h3 class="panel-title">
                                <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion"
                                    href="#filterPanel">Additional Rooms</a>
                                
                            </h3>
                        </div>
						<div class="col-sm-2">
                        <form>
                        <label class="checkbox-inline">
                         <input type="checkbox" value="">Servent room
                        </label>
						</div>
    <label class="checkbox-inline">
      <input type="checkbox" value="">Study room
    </label>
    <label class="checkbox-inline">
      <input type="checkbox" value="">Store room
    </label>
	<label class="checkbox-inline">
      <input type="checkbox" value="">Pent house
    </label>
	<label class="checkbox-inline">
      <input type="checkbox" value="">Poojaroom
    </label>
	</form>	
                    </div>
                    <!--	div class="row">
                        <div class="col-sm-3">
                            <div class="input-group">
                                <span class="input-group-addon">Washroom</span>
                                <select class="form-control" id="washroomtype" onchange="ShowHideDiv2()">
                                    <option value="" disabled selected>Select Washroom</option>
                                    <option value="nowashroom">None</option>
                                    <option>Attached</option>
                                    <option>Common</option>
                                    <option value="Both">Attached and Common</option>
                                </select>
                            </div>
                        </div>
                        <script type="text/javascript">
                            function ShowHideDiv2() {
                                var washroomtype = document.getElementById("washroomtype");
                                var washroomtypeselect = document.getElementById("washroomtypeselect");
                                washroomtypeselect.style.display = washroomtype.value == "nowashroom" ? "block" : "none";
                                washroomtypeselect1.style.display = washroomtype.value == "Attached" ? "block" : "none";
                                washroomtypeselect2.style.display = washroomtype.value == "Common" ? "block" : "none";
                                washroomtypeselect3.style.display = washroomtype.value == "Both" ? "block" : "none";
                            }
                        </script>
                        <div id="washroomtypeselect" style="display: nowashroom">
                            <div class="col-sm-3">
                                <div class="input-group">
                                    <span class="input-group-addon">No of Washroom</span>
                                    <select disabled class="form-control" id="sel1">
                                        <option></option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div id="washroomtypeselect1" style="display: none">
                            <div class="col-sm-3">
                                <div class="input-group">
                                    <span class="input-group-addon">Attached</span>
                                    <select class="form-control" id="sel1">
                                        <option>1</option>
                                        <option>2</option>
                                        <option>3</option>
                                        <option>4</option>
                                        <option>5</option>
                                        <option>5+</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div id="washroomtypeselect2" style="display: none">
                            <div class="col-sm-3">
                                <div class="input-group">
                                    <span class="input-group-addon">Common</span>
                                    <select class="form-control" id="sel1">
                                        <option>1</option>
                                        <option>2</option>
                                        <option>3</option>
                                        <option>4</option>
                                        <option>5</option>
                                        <option>5+</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div id="washroomtypeselect3" style="display: none">
                            <div class="col-sm-3">
                                <div class="input-group">
                                    <span class="input-group-addon">Attach</span>
                                    <select class="form-control" id="sel1">
                                        <option>1</option>
                                        <option>2</option>
                                        <option>3</option>
                                        <option>4</option>
                                        <option>5</option>
                                        <option>5+</option>
                                    </select>
                                    <span class="input-group-addon">Common</span>
                                    <select class="form-control" id="sel1">
                                        <option>1</option>
                                        <option>2</option>
                                        <option>3</option>
                                        <option>4</option>
                                        <option>5</option>
                                        <option>5+</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="col-sm-6">
                            <div class="input-group">
                                <span class="input-group-addon">Power Backup</span>
                                <select class="form-control" id="sel1">
                                    <option value="" disabled selected>Select Power Backup</option>
                                    <option>No Power Backup</option>
                                    <option>Fully</option>
                                    <option>Partially</option>
                                </select>
                            </div>
                        </div>
                    </div-->
					<div class="panel panel-default">
                        <div class="panel-heading">
                            <h3 class="panel-title">
                                <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion"
                                    href="#filterPanel">PriceInclude</a>
                                
                            </h3>
                        </div>
                        <form>
                                         <label class="checkbox-inline">
                                  <input type="checkbox" value="">Carparking
                                        </label>
                             <label class="checkbox-inline">
                             <input type="checkbox" value="">Clubmembership
                                         </label>
                                        <label class="checkbox-inline">
                                 <input type="checkbox" value="">Registration
                                  </label>

	                    </form>	
                    </div>
                    <br />
				
					
					
					
					
					
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="input-group">
                                <span class="input-group-addon required">Price</span>
                                <input type="number" value="" min="0" step="1" id="propprice" class="form-control"
                                    placeholder="Price">
                               
                                <span class="input-group-addon  required" >
                                    <div class="checkbox" style="padding-left: 0px; margin:0px;">
                                        <label>
                                            <input type="checkbox" value="on"
                                                style="position: absolute;visibility: visible;" name="p_negotiable">  
                                            Negotiable
                                        </label>
                                    </div>
                                </span>
                            </div>
                            <a data-toggle="collapse" data-target="#price" href="#price"
                                style="float:right; font-size:smaller">More/Less Price Option</a>
                        </div>
                        <div class="col-sm-6">
                            <div class="input-group">
                                <span class="input-group-addon  required">BookingAmount</span>
								<input type="text" id="fname" name="fname" value="RS"  style="    width: 90px;
    height: 29px;">
                                
                            </div>
                        </div>
						
                    </div>
                    


                    <br />
                    

                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h3 class="panel-title">
                                <a class="accordion-toggle  required" data-toggle="collapse" data-parent="#accordion"
                                    href="#filterPanel">Property Status</a>
                                <span class="pull-right panel-collapse-clickable" data-toggle="collapse"
                                    data-parent="#accordion" href="#filterPanel">
                                    <i class="glyphicon glyphicon-chevron-down"></i>
                                </span>
                            </h3>
                        </div>
                        <div id="filterPanel" class="panel-collapse collapse in">
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="input-group  required">
                                            <span class="input-group-addon  required">Transaction Type</span>
                                            <select class="form-control" id="propertytype">
                                                <option value="" disabled selected>Select Transaction Type</option>
                                                <option>New</option>
                                                <option>Resale</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="input-group">
                                            <span class="input-group-addon  required">Ownership Type</span>
                                            <select class="form-control  required" id="sel1">
                                                <option value="" disabled selected>Select Ownership Type</option>
                                                <option>Freehold</option>
                                                <option>Power of Attorney</option>
                                                <option>Leasehold</option>
                                                <option>Co-operative Society</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <br />
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="input-group">
                                            <span class="input-group-addon  required">Availability</span>
                                            <select class="form-control" id="availability" onchange="ShowHideDiv3()">
                                                <option value="UnderConstruction  required">Under Construction</option>
                                                <option value="ReadytoMove  required">Ready to Move</option>
                                            </select>
                                        </div>
                                    </div>
                                    <script type="text/javascript">
                                        function ShowHideDiv3() {
                                            var availability = document.getElementById("availability");
                                            var availabilityselect = document.getElementById("availabilityselect");
                                            availabilityselect.style.display = availability.value == "ReadytoMove" ? "block" : "none";
                                            availabilityselect2.style.display = availability.value == "UnderConstruction" ? "block" : "none";
                                        }
                                    </script>
                                    <div class="col-sm-6">
                                        <div id="availabilityselect" style="display: none">
                                            <div class="input-group">
                                                <span class="input-group-addon">Age of Property</span>
                                                <select class="form-control" id="sel1">
                                                    <option>New Property</option>
													<option>0 to 1 years</option>
                                                    <option>0 to 2 years</option>
                                                    <option>2 to 5 years</option>
                                                    <option>5 to 10 years</option>
                                                    <option>More than 10 years</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div id="availabilityselect2">
                                            <div class="input-group">
                                                <span class="input-group-addon">Possession By</span>
												<input type="date" id="start" name="trip-start" value="2018-07-22" min="2020-10-01" max="2020-12-31">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
					<div class="row">
                        <div class="col-sm-12">
						<label>Description</label>
                            <textarea placeholder="description (50 characters)" min="50" max="60" class="form-control"
                                name="p_description"> </textarea>
                        </div>
                    </div>
                    <br />

                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h3 class="panel-title">
                                <a data-toggle="collapse" data-parent="#accordion" href="#filterPane2">PropertyFeatures</a>
                                <span class="pull-right panel-collapse-clickable" data-toggle="collapse"
                                    data-parent="#accordion" href="#filterPane2">
                                    <i class="glyphicon glyphicon-chevron-down"></i>
                                </span>
                            </h3>
                        </div>
                        <div id="filterPane2" class="panel-collapse collapse in">
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="input-group">
                                            <label>
                                                <b>Furnishing:   </b>
                                            </label>
                                            <label class="radio-inline">
                                                <input type="radio" name="optradio" id="unfurnished">Unfurnished
                                            </label>
                                            <label class="radio-inline">
                                                <input type="radio" name="optradio" id="Semifurnished">Semifurnished
                                            </label>
                                            <label class="radio-inline">
                                                <input type="radio" name="optradio" id="Furnished">Furnished
                                            </label>
                                        </div>
                                    </div>
                                </div>
                                <br />

                                <script type="text/javascript">
                                    $(function () {
                                        $('#multicheck').multiselect({
                                            includeSelectAllOption: true,
                                            enableFiltering: true,
                                            enableCaseInsensitiveFiltering: true,
                                            buttonWidth: '100%',
                                            filterPlaceholder: 'Search Amenities',
                                        });
                                    });
                                </script>
                                <script type="text/javascript">
                                    $(function () {
                                        $('#multicheck2').multiselect({
                                            includeSelectAllOption: true,
                                            enableFiltering: true,
                                            enableCaseInsensitiveFiltering: true,
                                            buttonWidth: '100%',
                                            filterPlaceholder: 'Search Furnishing',
                                        });
                                    });
                                </script>

                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="input-group">
                                            <span class="input-group-addon">Amenities</span>
                                            <select id="multicheck" multiple="multiple">
                                                <option value="1">Security / Fire Alarm</option>
                                                <option value="2">Centrally Air Conditioned</option>
                                                <option value="3">Lift(s)</option>
                                                <option value="4">Security Personnel</option>
                                                <option value="5">Carparking</option>
                                                <option value="6">Visitors Parking</option>
                                                <option value="7">PowerBackup</option>
                                                <option value="8">Maintainance Staff</option>
                                                <option value="9">Wifi</option>
                                                <option value="10">Eatrhquake Resistant</option>
                                                <option value="11">Conferance Room</option>
                                                <option value="12">Garden</option>
                                                <option value="13">Fitness centre / Gym</option>
                                                <option value="14">Water Sotrage</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-sm-6" id="furnishinghide">
                                        <div class="input-group">
                                            <span class="input-group-addon">Furnishing</span>
                                            <select id="multicheck2" multiple="multiple">
                                                <option value="1">Beds</option>
                                                <option value="2">Air Conditioner</option>
                                                <option value="3">TV</option>
                                                <option value="4">Greasers</option>
                                                <option value="5">Fans</option>
                                                <option value="8">Water Dispenser</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <br />
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="input-group  required">
                                            <span class="input-group-addon  required">Car Parking</span>
                                            <select class="form-control" id="carparking" onchange="ShowHideDiv6()">
                                                <option value="" disabled selected>Car Parking Type</option>
                                                <option value="noparking">None</option>
                                                <option>Open</option>
                                                <option>Covered</option>
                                                <option value="Both">Open and Covered Both</option>
                                            </select>
                                        </div>
                                    </div>
                                    <script type="text/javascript">
                                        function ShowHideDiv6() {
                                            var carparking = document.getElementById("carparking");
                                            var carparkingselect = document.getElementById("carparkingselect");
                                            carparkingselect.style.display = carparking.value == "noparking" ? "block" : "none";
                                            carparkingselect1.style.display = carparking.value == "Open" ? "block" : "none";
                                            carparkingselect2.style.display = carparking.value == "Covered" ? "block" : "none";
                                            carparkingselect3.style.display = carparking.value == "Both" ? "block" : "none";
                                        }
                                    </script>
                                    <div id="carparkingselect" style="display: noparking">
                                        <div class="col-sm-6">
                                            <div class="input-group  required">
                                                <span class="input-group-addon  required">No of Car Parking</span>
                                                <select disabled class="form-control  required" id="sel1">
                                                    <option></option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div id="carparkingselect1" style="display: none">
                                        <div class="col-sm-6">
                                            <div class="input-group">
                                                <span class="input-group-addon  required">No. of Open</span>
                                                <select class="form-control  required" id="sel1">
                                                    <option>1</option>
                                                    <option>2</option>
                                                    <option>3</option>
                                                    <option>4</option>
                                                    <option>5</option>
                                                    <option>5+</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div id="carparkingselect2" style="display: none">
                                        <div class="col-sm-6">
                                            <div class="input-group  required">
                                                <span class="input-group-addon  required">No. of Covered</span>
                                                <select class="form-control  required" id="sel1">
                                                    <option>1</option>
                                                    <option>2</option>
                                                    <option>3</option>
                                                    <option>4</option>
                                                    <option>5</option>
                                                    <option>5+</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div id="carparkingselect3" style="display: none">
                                        <div class="col-sm-6">
                                            <div class="input-group">
                                                <span class="input-group-addon  required">No. of Open</span>
                                                <select class="form-control  required" id="sel1">
                                                    <option>1</option>
                                                    <option>2</option>
                                                    <option>3</option>
                                                    <option>4</option>
                                                    <option>5</option>
                                                    <option>5+</option>
                                                </select>
                                                <span class="input-group-addon  required">No. of Covered</span>
                                                <select class="form-control  required" id="sel1">
                                                    <option>1</option>
                                                    <option>2</option>
                                                    <option>3</option>
                                                    <option>4</option>
                                                    <option>5</option>
                                                    <option>5+</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
					
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h3 class="panel-title">
                                <a class="accordion-toggle  required" data-toggle="collapse" data-parent="#accordion"
                                    href="#filterPanel">Property Details</a>
                                <span class="pull-right panel-collapse-clickable" data-toggle="collapse"
                                    data-parent="#accordion" href="#filterPanel">
                                    <i class="glyphicon glyphicon-chevron-down"></i>
                                </span>
                            </h3>
                        </div>
                        <div id="filterPanel" class="panel-collapse collapse in">
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="input-group  required">
                                            <span class="input-group-addon  required">TotalFloors</span>
                                            <select class="form-control" id="propertytype">
                                                <option value="" disabled selected>Select TotalFloors</option>
                                                <option>01</option>
                                                <option>02</option>
												<option>03</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="input-group  required">
                                            <span class="input-group-addon  required">FloorNo</span>
                                            <select class="form-control" id="sel1">
                                                <option value="" disabled selected>Select FloorNo</option>
                                                <option>01</option>
                                                <option>02</option>
												<option>03</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <br />
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="input-group  required">
                                            <span class="input-group-addon  required">Facing</span>
                                            <select class="form-control" id="availability" onchange="ShowHideDiv3()">
                                                <option value="East">East</option>
                                                <option value="West">West</option>
												<option value="South">South</option>
												<option value="North">North</option>
												<option value="NorthEast">NorthEast</option>
												<option value="NorthWest">NorthWest</option>
												<option value="SouthEast">SouthEast</option>
												<option value="SouthWest">SouthWest</option>
                                            </select>
                                        </div>
                                    </div>
									<div class="col-sm-6">
                                        <div class="input-group  required">
                                            <span class="input-group-addon  required">Openside</span>
                                            <select class="form-control" id="availability" onchange="ShowHideDiv3()">
                                                <option value="01">01</option>
                                                <option value="02">02</option>
												<option value="03">03</option>
												<option value="04">04</option>
												
                                            </select>
                                        </div>
                                    </div>
                                    <script type="text/javascript">
                                        function ShowHideDiv3() {
                                            var availability = document.getElementById("availability");
                                            var availabilityselect = document.getElementById("availabilityselect");
                                            availabilityselect.style.display = availability.value == "ReadytoMove" ? "block" : "none";
                                            availabilityselect2.style.display = availability.value == "UnderConstruction" ? "block" : "none";
                                        }
                                    </script>
                                    <div class="col-sm-6">
                                        <div id="availabilityselect" style="display: none">
                                            <div class="input-group  required">
                                                <span class="input-group-addon  required">Age of Property</span>
                                                <select class="form-control" id="sel1">
                                                    <option>New Property</option>
													<option>0 to 1 years</option>
                                                    <option>0 to 2 years</option>
                                                    <option>2 to 5 years</option>
                                                    <option>5 to 10 years</option>
                                                    <option>More than 10 years</option>
                                                </select>
                                            </div>
                                        </div>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
					</div>
					<div class="panel panel-default ApartmentFlat box" >
                        <div class="panel-heading" >
                            <h3 class="panel-title">
                                <a data-toggle="collapse" data-parent="#accordion" href="#filterPane2">AdditionalDetails</a>
                                <span class="pull-right panel-collapse-clickable" data-toggle="collapse"
                                    data-parent="#accordion" href="#filterPane2">
                                    <i class="glyphicon glyphicon-chevron-down"></i>
                                </span>
                            </h3>
                        </div>
                        <div id="filterPane2" class="panel-collapse collapse in">
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-sm-4">
                                        <div class="input-group">
                                            <label>
                                                <b>Overlooking:   </b>
                                            </label>
                                            <form>
                                             <label class="checkbox-inline">
                                             <input type="checkbox" value="">cornerproperty
                                             </label>
                                             <label class="checkbox-inline">
                                             <input type="checkbox" value="">RoadFacility
                                             </label>
                                             <label class="checkbox-inline">
                                             <input type="checkbox" value="">park
                                             </label>
											</form>
                                        </div>
                                    </div>
									    <div class="col-sm-8">
                                        <div class="input-group">
                                            <label>
                                                <b>AdditionalFeatures:   </b>
                                            </label>
                                            <form>
                                               <label class="checkbox-inline">
                                               <input type="checkbox" value="">Sofa
                                               </label>
                                               <label class="checkbox-inline">
                                               <input type="checkbox" value="">Fridge
                                               <label class="checkbox-inline">
                                               <input type="checkbox" value="">WashingMachine
											   <label class="checkbox-inline">
                                               <input type="checkbox" value="">Microwave
											   <label class="checkbox-inline">
                                               <input type="checkbox" value="">GasConnection
                                            </label>
	
	
                                             </form>
                                        </div>
                                    </div>
                                </div>
				
							<div class="row">
								<div class="col-sm-4">
                                             <div class="input-group">
										       <label>
                                                <b>Flooring:   </b>
                                              </label>
											</div>
                                           
                                        <div class="input-group" ">
                                            <span class="input-group-addon">Livingroom</span>
                                            <select class="form-control" id="propertytype">
                                                <option value="" disabled selected>Select TotalFloors</option>
                                                <option>ceramic tiles</option>
                                                <option>vitrified tiles</option>
												<option>AntiSkid tiles</option>
												<option>granite tiles</option>
                                                <option>Wooden Flooring</option>
												<option>RAK/Laminated flooring</option>
												<option>WoodFinishing tiles</option>
												
                                            </select>
                                        </div>
                                </div>
								           <div class="col-sm-4">
                                             <div class="input-group">
										       <label>
                                               
                                              </label>
											</div>
                                           
                                             <div class="input-group" style="margin-top:17px;">
                                            <span class="input-group-addon">Kitchen</span>
                                            <select class="form-control" id="propertytype">
                                                <option value="" disabled selected>Select TotalFloors</option>
                                                <option>ceramic tiles</option>
                                                <option>vitrified tiles</option>
												<option>AntiSkid tiles</option>
												<option>granite tiles</option>
                                                <option>Wooden Flooring</option>
												<option>RAK/Laminated flooring</option>
												<option>WoodFinishing tiles</option>
                                            </select>
                                              </div>
                                           </div>
										    <div class="col-sm-4">
                                             <div class="input-group">
										       <label>
                                               
                                              </label>
											</div>
                                           
                                             <div class="input-group" style="margin-top:17px; ">
                                            <span class="input-group-addon">Bathroom</span>
                                            <select class="form-control" id="propertytype">
                                                <option value="" disabled selected>Select TotalFloors</option>
                                                <option>ceramic tiles</option>
                                                <option>vitrified tiles</option>
												<option>AntiSkid tiles</option>
												<option>granite tiles</option>
                                                <option>Wooden Flooring</option>
												<option>RAK/Laminated flooring</option>
												<option>WoodFinishing tiles</option>
                                            </select>
                                              </div>
                                           </div>

                            </div>  
                                       
										
                            <div class="row">
								<div class="col-sm-4">
                                             <div class="input-group">
										       <label>

                                              </label>
											</div>
                                           
                                        <div class="input-group" style="margin-top:9px;">
                                            <span class="input-group-addon">MasterBedroom</span>
                                            <select class="form-control" id="propertytype">
                                                <option value="" disabled selected>Select TotalFloors</option>
                                                <option>ceramic tiles</option>
                                                <option>vitrified tiles</option>
												<option>AntiSkid tiles</option>
												<option>granite tiles</option>
                                                <option>Wooden Flooring</option>
												<option>RAK/Laminated flooring</option>
												<option>WoodFinishing tiles</option>
                                            </select>
                                        </div>
                                </div>
								<div class="col-sm-4">
                                             <div class="input-group">
										       <label>
                                               
                                              </label>
											</div>
                                           
                                        <div class="input-group" style="margin-top:9px;">
                                            <span class="input-group-addon">Balcony</span>
                                            <select class="form-control" id="propertytype">
                                                <option value="" disabled selected>Select TotalFloors</option>
                                               <option>ceramic tiles</option>
                                                <option>vitrified tiles</option>
												<option>AntiSkid tiles</option>
												<option>granite tiles</option>
                                                <option>Wooden Flooring</option>
												<option>RAK/Laminated flooring</option>
												<option>WoodFinishing tiles</option>
                                            </select>
                                        </div>
                                </div>
								<div class="col-sm-4">
                                             <div class="input-group">
										       <label>
                                               
                                              </label>
											</div>
                                           
                                        <div class="input-group" style="margin-top:9px;">
                                            <span class="input-group-addon">OtherRooms</span>
                                            <select class="form-control" id="propertytype">
                                                <option value="" disabled selected>Select TotalFloors</option>
                                                <option>ceramic tiles</option>
                                                <option>vitrified tiles</option>
												<option>AntiSkid tiles</option>
												<option>granite tiles</option>
                                                <option>Wooden Flooring</option>
												<option>RAK/Laminated flooring</option>
												<option>WoodFinishing tiles</option>
                                            </select>
                                        </div>
                                </div>
                                          
                            </div>
				
                                    </div>
									</div>
								
                                <br />

                                <script type="text/javascript">
                                    $(function () {
                                        $('#multicheck').multiselect({
                                            includeSelectAllOption: true,
                                            enableFiltering: true,
                                            enableCaseInsensitiveFiltering: true,
                                            buttonWidth: '100%',
                                            filterPlaceholder: 'Search Amenities',
                                        });
                                    });
                                </script>
                                <script type="text/javascript">
                                    $(function () {
                                        $('#multicheck2').multiselect({
                                            includeSelectAllOption: true,
                                            enableFiltering: true,
                                            enableCaseInsensitiveFiltering: true,
                                            buttonWidth: '100%',
                                            filterPlaceholder: 'Search Furnishing',
                                        });
                                    });
                                </script>

                                
                                <br />
                               
							   
                            </div>
                        </div>

                    </div>




                </div>



                <div id="propertytypeselect2" style="display:none">
                    <div class="col-sm-6">
                        <div class="input-group">
                            <span class="input-group-addon">Plot Area</span>
                            <input type="text" class="form-control">
                        </div>
                    </div>
                    <br />
                    <br /> <br />
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="input-group">
                                <span class="input-group-addon">Open Side</span>
                                <select class="form-control" id="propertytype">
                                    <option value="" disabled selected>Select Open Sides</option>
                                    <option>1 Side Open</option>
                                    <option>2 Side Open</option>
                                    <option>3 Side Open</option>
                                    <option>4 Side Open</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="input-group">
                                <span class="input-group-addon">Total Floor Allowed</span>
                                <select class="form-control" id="sel1">
                                    <option value="" disabled selected>Select Floor Allowed</option>
                                    <option>Basement</option>
                                    <option>Ground</option>
                                    <option>Upper Ground</option>
                                    <option>1st Floor</option>
                                    <option>2nd Floor</option>
                                    <option>3rd Floor</option>
                                    <option>4th Floor</option>
                                    <option>5th Floor</option>
                                    <option>6th Floor</option>
                                    <option>7th Floor</option>
                                    <option>8th Floor</option>
                                    <option>9th Floor</option>
                                    <option>10th Floor</option>
                                    <option>11th Floor</option>
                                    <option>12th Floor</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <br />
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="input-group">
                                <span class="input-group-addon">Facing</span>
                                <select class="form-control" id="sel1">
                                    <option value="" disabled selected>Select Facing</option>
                                    <option value="nowashroom">East</option>
                                    <option>West</option>
                                    <option>North</option>
                                    <option>South</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="input-group">
                                <span class="input-group-addon">Facing Road Width</span>
                                <input type="text" class="form-control" />
                            </div>
                        </div>
                    </div>
                    <br />
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="input-group">
                                <span class="input-group-addon">Price</span>
                                <input type="number" value="" min="0" step="1" id="propprice" class="form-control"
                                    placeholder="Price">
                                <span class="input-group-addon">₹</span>
                                <span class="input-group-addon">
                                    <div class="checkbox" style="padding-left: 0px; margin:0px;">
                                        <label>
                                            <input type="checkbox" value="on"
                                                style="position: absolute;visibility: visible;" name="p_negotiable">  
                                            Negotiable
                                        </label>
                                    </div>
                                </span>
                            </div>
                            <a data-toggle="collapse" data-target="#price1" href="#price1"
                                style="float:right; font-size:smaller">More/Less Price Option</a>
                        </div>
                        <div class="col-sm-6">
                            <div class="input-group">
                                <span class="input-group input-group-addon">Price Per</span>
                                <input disabled type="text" class="form-control" value=""
                                    placeholder="Price Per Sq.Yrd" />
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div id="price1" class="panel-collapse collapse">
                            <div class="col-sm-4">
                                <div class="input-group">
                                    <span class="input-group-addon">Maintainance</span>
                                    <input type="text" class="form-control" placeholder="Enter Amount">
                                    <span class="input-group-addon">₹</span>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="input-group">
                                    <span class="input-group-addon">Brokerage</span>
                                    <input type="text" class="form-control" placeholder="Enter Amount">
                                    <span class="input-group-addon">₹</span>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="input-group">
                                    <span class="input-group-addon">Booking Amount</span>
                                    <input type="text" class="form-control" placeholder="Enter Amount">
                                    <span class="input-group-addon">₹</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <br />
                    <div class="row">
                        <div class="col-sm-12">
                            <textarea placeholder="description (50 characters)" min="50" max="60" class="form-control"
                                name="p_description"> </textarea>
                        </div>
                    </div>
                    <br />

                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h3 class="panel-title">
                                <a data-toggle="collapse" data-parent="#accordion" href="#filterPane3">Property
                                    Status</a>
                                <span class="pull-right panel-collapse-clickable" data-toggle="collapse"
                                    data-parent="#accordion" href="#filterPane3">
                                    <i class="glyphicon glyphicon-chevron-down"></i>
                                </span>
                            </h3>
                        </div>
                        <div id="filterPane3" class="panel-collapse collapse in">
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="input-group">
                                            <span class="input-group-addon">Transaction Type</span>
                                            <select class="form-control" id="propertytype">
                                                <option value="" disabled selected>Select Transaction Type</option>
                                                <option>New</option>
                                                <option>Resale</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="input-group">
                                            <span class="input-group-addon">Ownership Type</span>
                                            <select class="form-control" id="sel1">
                                                <option value="" disabled selected>Select Ownership Type</option>
                                                <option>Freehold</option>
                                                <option>Power of Attorney</option>
                                                <option>Leasehold</option>
                                                <option>Co-operative Society</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h3 class="panel-title">
                                <a data-toggle="collapse" data-parent="#accordion" href="#filterPane2">Additional
                                    Detail</a>
                                <span class="pull-right panel-collapse-clickable" data-toggle="collapse"
                                    data-parent="#accordion" href="#filterPane2">
                                    <i class="glyphicon glyphicon-chevron-down"></i>
                                </span>
                            </h3>
                        </div>
                        <div id="filterPane2" class="panel-collapse collapse in">
                            <div class="panel-body">
                                <script type="text/javascript">
                                    $(function () {
									alert();
                                        $('#multicheck3').multiselect({
                                            includeSelectAllOption: true,
                                            enableFiltering: true,
                                            enableCaseInsensitiveFiltering: true,
                                            buttonWidth: '100%',
                                            filterPlaceholder: 'Search Amenities',
                                        });
                                    });
                                </script>

                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="input-group">
                                            <span class="input-group-addon">Amenities</span>
                                            <select id="multicheck3" multiple="multiple">
                                                <option value="1">Security / Fire Alarm</option>
                                                <option value="2">Centrally Air Conditioned</option>
                                                <option value="3">Lift(s)</option>
                                                <option value="4">Security Personnel</option>
                                                <option value="5">Cafeteria / Food Court</option>
                                                <option value="6">Visitors Parking</option>
                                                <option value="7">Service / Goods Lift</option>
                                                <option value="8">Maintainance Staff</option>
                                                <option value="9">Wifi</option>
                                                <option value="10">Eatrhquake Resistant</option>
                                                <option value="11">Conferance Room</option>
                                                <option value="12">Intercom facility</option>
                                                <option value="13">Fitness centre / Gym</option>
                                                <option value="14">Water Sotrage</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>

    </form>
</body>
<script>
    $(document).ready(function () {

        $("#watch-me").click(function () {
            $("#show-me:hidden").show('slow');

            $("#show-me-two").hide();

            $("#show-me-three").hide();

        });

        $("#watch-me").click(function () {

            if ($('watch-me').prop('checked') === false) {

                $('#show-me').hide();

            }

        });




        $("#see-me").click(function () {
            $("#show-me-two:hidden").show('slow');
            $("#show-me").hide();
            $("#show-me-three").hide();
        });
        $("#see-me").click(function () {
            if ($('see-me-two').prop('checked') === false) {
                $('#show-me-two').hide();
            }
        });







        $("#look-me").click(function () {
            $("#show-me-three:hidden").show('slow');
            $("#show-me").hide();
            $("#show-me-two").hide();
        });
        $("#look-me").click(function () {
            if ($('see-me-three').prop('checked') === false) {
                $('#show-me-three').hide();
            }
        });

    });

</script>
<div class="container ApartmentFlat box" style="margin-top:10px;">
    <fieldset class="form-group">
        <a href="javascript:void(0)" onclick="$('#pro-image').click()">Upload Image</a>
        <input type="file" id="pro-image" name="pro-image" style="display: none;" class="form-control"  placeholder=" Upload Image"multiple>
    </fieldset>
    <div class="preview-images-zone">
        
        
        
    </div>
</div>
<div class="container ApartmentFlat box">
 
  <p>PostedBy:</p>
  <form>
    <label class="radio-inline">
      <input type="radio" name="optradio" checked>Agent
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio">Owner
    </label>
	<label class="radio-inline">
      <input type="radio" name="optradio">Others
    </label>
	
	<br>
  
</div>


                       <!--for rent apartment-->
			    <div class="container ApartmentFlat box">
					<div class="row">
                            <div class="col-sm-3">
                                <div class="input-group">
                                    <span class="input-group input-group-addon">MonthlyRent</span>
                                    <input  type="number" class="form-control"placeholder="Enter Amount in Rs" />
                                </div>
								<div class="checkbox" style="padding-left: 10px; margin:0px;">
                                        <label>
                                            <input type="checkbox" value="on"
                                                style="position: absolute;visibility: visible;" name="p_negotiable">  
                                            Negotiable
                                        </label>
                                    </div>
                            </div>
                            <div class="col-sm-3">
                                <div class="input-group">
                                  <span class="input-group-addon">SecurityDeposit</span>
                                    <select class="form-control" id="type">
                                        <option value="" disabled selected>SecurityDeposit</option>
                                        <option value="1">00 Month</option>
                                        <option value="1">01 Month</option>
                                        <option value="1">02 Month</option>
                                        <option value="1">03 Month</option>
                                        <option value="1">04 Month</option>
                                        <option value="1">05 Month</option>
                                        <option value="1">06 Month</option>
							            <option value="2">07 Month</option>
							            <option value="2">08 Month</option>
							                            
                                    </select>
                                </div>
                            </div>
                            <div class="col-sm-3" >
                                <div class="input-group">
                                    <span class="input-group-addon">Maintainance</span>
                                    <input type="text" class="form-control" placeholder="Enter Amount in Rs">
                                    
                                </div>
                            </div>
                            <div class="col-sm-3">
                                <div class="input-group">
                                                <span class="input-group-addon">Available From</span>
												<input type="date" id="start" style="height:34px"name="trip-start" value="2018-07-22" min="2020-10-01" max="2020-12-31">
                                            </div>
                            </div>
                        </div>
                    </div>
				</div>
					
					<!-- end for rent apartment-->










<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script>
$(document).ready(function(){
    $("#propertytype1").change(function(){
        $(this).find("option:selected").each(function(){
            var optionValue = $(this).attr("value");
            if(optionValue){
                $(".box").not("." + optionValue).hide();
                $("." + optionValue).show();
            } else{
                $(".box").hide();
            }
        });
    }).change();
});
</script>
<script>
$(document).ready(function(){
    $("#propertytype1").change(function(){
        $(this).find("option:selected").each(function(){
            var optionValue = $(this).attr("value");
            if(optionValue){
                $(".box").not("." + optionValue).hide();
                $("." + optionValue).show();
            } else{
                $(".box").hide();
            }
        });
    }).change();
});
</script>





                                            <!-- Villa Code-->
					<div id="propertytypeselect" class="Villas box" style="display:1">
                    <div class="col-sm-4">
                    <div class="input-group">
                        <span class="input-group-addon">Bedrooms</span>
                        <select class="form-control required" id="propertytype" onchange="ShowHideDiv()">
                            <option value="" disabled selected>Select Bedrooms</option>
                           
                            <option value="1">01BHK</option>
                            <option value="1">02BHK</option>
                            <option value="1">03BHK</option>
                            <option value="1">04BHK</option>
                            <option value="1">05BHK</option>
                            <option value="1">06BHK</option>
							<option value="2">07BHK</option>
							<option value="2">08BHK</option>
							                            
                        </select>
                    </div>
					
					
                </div>
				                    <div class="col-sm-4">
                    <div class="input-group">
                        <span class="input-group-addon">Balcony</span>
                        <select class="form-control" id="propertytype" onchange="ShowHideDiv()">
                            <option value="" disabled selected>Select Balcony</option>
                            
                            <option value="1">01</option>
                            <option value="1">02</option>
                            <option value="1">03</option>
                            <option value="1">04</option>
                            <option value="1">05</option>
                            <option value="1">06</option>
							<option value="2">07</option>
							<option value="2">08</option>
							                            
                        </select>
                    </div>
					</div>
					 <div class="col-sm-4">
                    <div class="input-group">
                        <span class="input-group-addon">Bathrooms</span>
                        <select class="form-control" id="propertytype" onchange="ShowHideDiv()">
                            <option value="" disabled selected>Select Bathrooms</option>
                           
                            <option value="1">01</option>
                            <option value="1">02</option>
                            <option value="1">03</option>
                            <option value="1">04</option>
                            <option value="1">05</option>
                            <option value="1">06</option>
							<option value="2">07</option>
							<option value="2">08</option>
							                            
                        </select>
                    </div>
					</div>
					

                    <div class="row">
                        <div id="carpet" class="panel-collapse collapse">
                            <div class="col-sm-6">
                                <div class="input-group">
                                    <span class="input-group-addon">Carpet Area</span>
                                    <input type="text" class="form-control">
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="input-group">
                                    <span class="input-group-addon">Plot Area</span>
                                    <input type="text" class="form-control">
                                </div>
                            </div>
                        </div>
                    </div>
                    <br />
                    
                <div class="row">
				      
                       <div class="col-sm-4">
                           <div class="row">
							<div class="input-group">
                                <span class="input-group-addon">Total Area</span>
                                <select class="form-control required" id="sel1">
                                    <option value="" disabled selected>Select Total Area</option>
                                    <option>SqYards</option>
                                    <option>Sqft</option>
									
                                </select>
								 
                            </div>
							
							
							</div>
                        </div>
						<div class="col-sm-2" style="padding-right: 127px;padding-left: 0px;">
                                <input type="text" class="form-control">
                        </div>
                        <div class="col-sm-4">
                           <div class="row">
							<div class="input-group">
                                <span class="input-group-addon">BuildUp Area</span>
                                <select class="form-control required" id="sel1">
                                    <option value="" disabled selected>Select BuildUp Area</option>
                                    <option>Sqft</option>
                                    <option>SqYards</option>
									
                                </select>
								 
                            </div>
							
							
							</div>
                        </div>
						<div class="col-sm-2" style="padding-right: 127px;padding-left: 0px;">
                                <input type="text" class="form-control">
                    </div>
					<d
				</div>
				<br>
				<div class="row">
				       
						<div class="col-sm-4">
                           <div class="row">
							<div class="input-group">
                                <span class="input-group-addon">Carpet Area</span>
                                <select class="form-control required" id="sel1">
                                    <option value="" disabled selected>Select Carpet Area</option>
                                    <option>Sqft</option>
                                    <option>SqYards</option>
									
                                </select>
								 
                            </div>
							
							
							</div>
                        </div>
						<div class="col-sm-2" style="padding-right: 127px;padding-left: 0px;">
                                <input type="text" class="form-control">
                        </div>
					
                    <br />
				</div><br>
                    <br />
					                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h3 class="panel-title">
                                <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion"
                                    href="#filterPanel">Additional Rooms</a>
                                
                            </h3>
                        </div>
                        <form>
    <label class="checkbox-inline">
      <input type="checkbox" value="">Servent room
    </label>
    <label class="checkbox-inline">
      <input type="checkbox" value="">Study room
    </label>
    <label class="checkbox-inline">
      <input type="checkbox" value="">Store room
    </label>
	<label class="checkbox-inline">
      <input type="checkbox" value="">Pent house
    </label>
	<label class="checkbox-inline">
      <input type="checkbox" value="">Poojaroom
    </label>
	</form>	
                    </div>
                   
					<div class="panel panel-default">
                        <div class="panel-heading">
                            <h3 class="panel-title">
                                <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion"
                                    href="#filterPanel">PriceInclude</a>
                                
                            </h3>
                        </div>
                        <form>
                                         <label class="checkbox-inline">
                                  <input type="checkbox" value="">Carparking
                                        </label>
                             <label class="checkbox-inline">
                             <input type="checkbox" value="">Clubmembership
                                         </label>
                                        <label class="checkbox-inline">
                                 <input type="checkbox" value="">Registration
                                  </label>

	                    </form>	
                    </div>
                    <br />
				
					
					
					
					
					
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="input-group">
                                <span class="input-group-addon required">Price</span>
                                <input type="number" value="" min="0" step="1" id="propprice" class="form-control"
                                    placeholder="Price">
                               
                                <span class="input-group-addon  required" >
                                    <div class="checkbox" style="padding-left: 0px; margin:0px;">
                                        <label>
                                            <input type="checkbox" value="on"
                                                style="position: absolute;visibility: visible;" name="p_negotiable">  
                                            Negotiable
                                        </label>
                                    </div>
                                </span>
                            </div>
                            <a data-toggle="collapse" data-target="#price" href="#price"
                                style="float:right; font-size:smaller">More/Less Price Option</a>
                        </div>
                        <div class="col-sm-6">
                            <div class="input-group">
                                <span class="input-group-addon  required">BookingAmount</span>
								<input type="text" id="fname" name="fname" value="RS"  style="    width: 90px;
    height: 29px;">
                                
                            </div>
                        </div>
						
                    </div>
                    


                    <br />
                    

                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h3 class="panel-title">
                                <a class="accordion-toggle  required" data-toggle="collapse" data-parent="#accordion"
                                    href="#filterPanel">Property Status</a>
                                <span class="pull-right panel-collapse-clickable" data-toggle="collapse"
                                    data-parent="#accordion" href="#filterPanel">
                                    <i class="glyphicon glyphicon-chevron-down"></i>
                                </span>
                            </h3>
                        </div>
                        <div id="filterPanel" class="panel-collapse collapse in">
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="input-group  required">
                                            <span class="input-group-addon  required">Transaction Type</span>
                                            <select class="form-control" id="propertytype">
                                                <option value="" disabled selected>Select Transaction Type</option>
                                                <option>New</option>
                                                <option>Resale</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="input-group">
                                            <span class="input-group-addon  required">Ownership Type</span>
                                            <select class="form-control  required" id="sel1">
                                                <option value="" disabled selected>Select Ownership Type</option>
                                                <option>Freehold</option>
                                                <option>Power of Attorney</option>
                                                <option>Leasehold</option>
                                                <option>Co-operative Society</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <br />
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="input-group">
                                            <span class="input-group-addon  required">Availability</span>
                                            <select class="form-control" id="availability" onchange="ShowHideDiv3()">
                                                <option value="UnderConstruction  required">Under Construction</option>
                                                <option value="ReadytoMove  required">Ready to Move</option>
                                            </select>
                                        </div>
                                    </div>
                                    <script type="text/javascript">
                                        function ShowHideDiv3() {
                                            var availability = document.getElementById("availability");
                                            var availabilityselect = document.getElementById("availabilityselect");
                                            availabilityselect.style.display = availability.value == "ReadytoMove" ? "block" : "none";
                                            availabilityselect2.style.display = availability.value == "UnderConstruction" ? "block" : "none";
                                        }
                                    </script>
                                    <div class="col-sm-6">
                                        <div id="availabilityselect" style="display: none">
                                            <div class="input-group">
                                                <span class="input-group-addon">Age of Property</span>
                                                <select class="form-control" id="sel1">
                                                    <option>New Property</option>
													<option>0 to 1 years</option>
                                                    <option>0 to 2 years</option>
                                                    <option>2 to 5 years</option>
                                                    <option>5 to 10 years</option>
                                                    <option>More than 10 years</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div id="availabilityselect2">
                                            <div class="input-group">
                                                <span class="input-group-addon">Possession By</span>
												<input type="date" id="start" style="height:32px;" name="trip-start" value="2018-07-22" min="2020-10-01" max="2020-12-31">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
					<div class="row">
                        <div class="col-sm-12">
						<label>Description</label>
                            <textarea placeholder="description (50 characters)" min="50" max="60" class="form-control"
                                name="p_description"> </textarea>
                        </div>
                    </div>
                    <br />

                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h3 class="panel-title">
                                <a data-toggle="collapse" data-parent="#accordion" href="#filterPane2">PropertyFeatures</a>
                                <span class="pull-right panel-collapse-clickable" data-toggle="collapse"
                                    data-parent="#accordion" href="#filterPane2">
                                    <i class="glyphicon glyphicon-chevron-down"></i>
                                </span>
                            </h3>
                        </div>
                        <div id="filterPane2" class="panel-collapse collapse in">
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="input-group">
                                            <label>
                                                <b >Furnishing:   </b>
                                            </label>
                                            <label class="radio-inline">
                                                <input type="radio" name="optradio" id="unfurnished">Unfurnished
                                            </label>
                                            <label class="radio-inline">
                                                <input type="radio" name="optradio" id="Semifurnished">Semifurnished
                                            </label>
                                            <label class="radio-inline">
                                                <input type="radio" name="optradio" id="Furnished">Furnished
                                            </label>
                                        </div>
                                    </div>
                                </div>
                                <br />

                                <script type="text/javascript">
                                    $(function () {
                                        $('#multicheck').multiselect({
                                            includeSelectAllOption: true,
                                            enableFiltering: true,
                                            enableCaseInsensitiveFiltering: true,
                                            buttonWidth: '100%',
                                            filterPlaceholder: 'Search Amenities',
                                        });
                                    });
                                </script>
                                <script type="text/javascript">
                                    $(function () {
                                        $('#multicheck2').multiselect({
                                            includeSelectAllOption: true,
                                            enableFiltering: true,
                                            enableCaseInsensitiveFiltering: true,
                                            buttonWidth: '100%',
                                            filterPlaceholder: 'Search Furnishing',
                                        });
                                    });
                                </script>

                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="input-group">
                                            <span class="input-group-addon">Amenities</span>
                                            <select id="multicheck" multiple="multiple">
                                                <option value="1">Security / Fire Alarm</option>
                                                <option value="2">Centrally Air Conditioned</option>
                                                <option value="3">Lift(s)</option>
                                                <option value="4">Security Personnel</option>
                                                <option value="5">Carparking</option>
                                                <option value="6">Visitors Parking</option>
                                                <option value="7">PowerBackup</option>
                                                <option value="8">Maintainance Staff</option>
                                                <option value="9">Wifi</option>
                                                <option value="10">Eatrhquake Resistant</option>
                                                <option value="11">Conferance Room</option>
                                                <option value="12">Garden</option>
                                                <option value="13">Fitness centre / Gym</option>
                                                <option value="14">Water Sotrage</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-sm-6"id="furnishinghide">
                                        <div class="input-group">
                                            <span class="input-group-addon">Furnishing</span>
                                            <select id="multicheck2" multiple="multiple">
                                                <option value="1">Beds</option>
                                                <option value="2">Air Conditioner</option>
                                                <option value="3">TV</option>
                                                <option value="4">Greasers</option>
                                                <option value="5">Fans</option>
                                                <option value="8">Water Dispenser</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <br />
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="input-group  required">
                                            <span class="input-group-addon  required">Car Parking</span>
                                            <select class="form-control" id="carparking" onchange="ShowHideDiv6()">
                                                <option value="" disabled selected>Car Parking Type</option>
                                                <option value="noparking">None</option>
                                                <option>Open</option>
                                                <option>Covered</option>
                                                <option value="Both">Open and Covered Both</option>
                                            </select>
                                        </div>
                                    </div>
                                    <script type="text/javascript">
                                        function ShowHideDiv6() {
                                            var carparking = document.getElementById("carparking");
                                            var carparkingselect = document.getElementById("carparkingselect");
                                            carparkingselect.style.display = carparking.value == "noparking" ? "block" : "none";
                                            carparkingselect1.style.display = carparking.value == "Open" ? "block" : "none";
                                            carparkingselect2.style.display = carparking.value == "Covered" ? "block" : "none";
                                            carparkingselect3.style.display = carparking.value == "Both" ? "block" : "none";
                                        }
                                    </script>
                                    <div id="carparkingselect" style="display: noparking">
                                        <div class="col-sm-6">
                                            <div class="input-group  required">
                                                <span class="input-group-addon  required">No of Car Parking</span>
                                                <select disabled class="form-control  required" id="sel1">
                                                    <option></option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div id="carparkingselect1" style="display: none">
                                        <div class="col-sm-6">
                                            <div class="input-group">
                                                <span class="input-group-addon  required">No. of Open</span>
                                                <select class="form-control  required" id="sel1">
                                                    <option>1</option>
                                                    <option>2</option>
                                                    <option>3</option>
                                                    <option>4</option>
                                                    <option>5</option>
                                                    <option>5+</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div id="carparkingselect2" style="display: none">
                                        <div class="col-sm-6">
                                            <div class="input-group  required">
                                                <span class="input-group-addon  required">No. of Covered</span>
                                                <select class="form-control  required" id="sel1">
                                                    <option>1</option>
                                                    <option>2</option>
                                                    <option>3</option>
                                                    <option>4</option>
                                                    <option>5</option>
                                                    <option>5+</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div id="carparkingselect3" style="display: none">
                                        <div class="col-sm-6">
                                            <div class="input-group">
                                                <span class="input-group-addon  required">No. of Open</span>
                                                <select class="form-control  required" id="sel1">
                                                    <option>1</option>
                                                    <option>2</option>
                                                    <option>3</option>
                                                    <option>4</option>
                                                    <option>5</option>
                                                    <option>5+</option>
                                                </select>
                                                <span class="input-group-addon  required">No. of Covered</span>
                                                <select class="form-control  required" id="sel1">
                                                    <option>1</option>
                                                    <option>2</option>
                                                    <option>3</option>
                                                    <option>4</option>
                                                    <option>5</option>
                                                    <option>5+</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
					
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h3 class="panel-title">
                                <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion"
                                    href="#filterPanel">Property Details</a>
                                <span class="pull-right panel-collapse-clickable" data-toggle="collapse"
                                    data-parent="#accordion" href="#filterPanel">
                                    <i class="glyphicon glyphicon-chevron-down"></i>
                                </span>
                            </h3>
                        </div>
                        <div id="filterPanel" class="panel-collapse collapse in">
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-sm-4">
                                        <div class="input-group">
                                            <span class="input-group-addon">TotalFloors</span>
                                            <select class="form-control" id="propertytype">
                                                <option value="" disabled selected>Select TotalFloors</option>
                                                <option>01</option>
                                                <option>02</option>
												<option>03</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-sm-4">
                                        <div class="input-group">
                                            <span class="input-group-addon">Openside</span>
                                            <select class="form-control" id="sel1">
                                                <option value="" disabled selected>Select FloorNo</option>
                                                <option>01</option>
                                                <option>02</option>
												<option>03</option>
                                            </select>
                                        </div>
                                    </div>
                                
                                
                                    <div class="col-sm-4">
                                        <div class="input-group">
                                            <span class="input-group-addon">Facing</span>
                                            <select class="form-control" id="availability" onchange="ShowHideDiv3()">
                                                <option value="East">East</option>
                                                <option value="West">West</option>
												<option value="South">South</option>
												<option value="North">North</option>
												<option value="NorthEast">NorthEast</option>
												<option value="NorthWest">NorthWest</option>
												<option value="SouthEast">SouthEast</option>
												<option value="SouthWest">SouthWest</option>
                                            </select>
                                        </div>
                                    </div>
									
                                    <script type="text/javascript">
                                        function ShowHideDiv3() {
                                            var availability = document.getElementById("availability");
                                            var availabilityselect = document.getElementById("availabilityselect");
                                            availabilityselect.style.display = availability.value == "ReadytoMove" ? "block" : "none";
                                            availabilityselect2.style.display = availability.value == "UnderConstruction" ? "block" : "none";
                                        }
                                    </script>
                                    <div class="col-sm-6">
                                        <div id="availabilityselect" style="display: none">
                                            <div class="input-group">
                                                <span class="input-group-addon">Age of Property</span>
                                                <select class="form-control" id="sel1">
                                                    <option>New Property</option>
													<option>0 to 1 years</option>
                                                    <option>0 to 2 years</option>
                                                    <option>2 to 5 years</option>
                                                    <option>5 to 10 years</option>
                                                    <option>More than 10 years</option>
                                                </select>
                                            </div>
                                        </div>
                                        
                                    </div>
                                </div>
                            </div>
					<div class="panel panel-default Villas box">
                        <div class="panel-heading">
                            <h3 class="panel-title">
                                <a data-toggle="collapse" data-parent="#accordion" href="#filterPane2">AdditionalDetails</a>
                                <span class="pull-right panel-collapse-clickable" data-toggle="collapse"
                                    data-parent="#accordion" href="#filterPane2">
                                    <i class="glyphicon glyphicon-chevron-down"></i>
                                </span>
                            </h3>
                        </div>
                        <div id="filterPane2" class="panel-collapse collapse in">
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-sm-4">
                                        <div class="input-group">
                                            <label>
                                                <b>Overlooking:   </b>
                                            </label>
                                            <form>
                                             <label class="checkbox-inline">
                                             <input type="checkbox" value="">cornerproperty
                                             </label>
                                             <label class="checkbox-inline">
                                             <input type="checkbox" value="">RoadFacility
                                             </label>
                                             <label class="checkbox-inline">
                                             <input type="checkbox" value="">park
                                             </label>
											</form>
                                        </div>
                                    </div>
									    <div class="col-sm-8">
                                        <div class="input-group">
                                            <label>
                                                <b>AdditionalFeatures:   </b>
                                            </label>
                                            <form>
                                               <label class="checkbox-inline">
                                               <input type="checkbox" value="">Sofa
                                               </label>
                                               <label class="checkbox-inline">
                                               <input type="checkbox" value="">Fridge
                                               <label class="checkbox-inline">
                                               <input type="checkbox" value="">WashingMachine
											   <label class="checkbox-inline">
                                               <input type="checkbox" value="">Microwave
											   <label class="checkbox-inline">
                                               <input type="checkbox" value="">GasConnection
                                            </label>
	
	
                                             </form>
                                        </div>
                                    </div>
                                </div>
				
							<div class="row">
								<div class="col-sm-4">
                                             <div class="input-group">
										       <label>
                                                <b>Flooring:   </b>
                                              </label>
											</div>
                                           
                                        <div class="input-group" ">
                                            <span class="input-group-addon">Livingroom</span>
                                            <select class="form-control" id="propertytype">
                                                <option value="" disabled selected>Select TotalFloors</option>
                                                <option>ceramic tiles</option>
                                                <option>vitrified tiles</option>
												<option>AntiSkid tiles</option>
												<option>granite tiles</option>
                                                <option>Wooden Flooring</option>
												<option>RAK/Laminated flooring</option>
												<option>WoodFinishing tiles</option>
												
                                            </select>
                                        </div>
                                </div>
								           <div class="col-sm-4">
                                             <div class="input-group">
										       <label>
                                               
                                              </label>
											</div>
                                           
                                             <div class="input-group" style="margin-top:17px;">
                                            <span class="input-group-addon">Kitchen</span>
                                            <select class="form-control" id="propertytype">
                                                <option value="" disabled selected>Select TotalFloors</option>
                                                <option>ceramic tiles</option>
                                                <option>vitrified tiles</option>
												<option>AntiSkid tiles</option>
												<option>granite tiles</option>
                                                <option>Wooden Flooring</option>
												<option>RAK/Laminated flooring</option>
												<option>WoodFinishing tiles</option>
                                            </select>
                                              </div>
                                           </div>
										    <div class="col-sm-4">
                                             <div class="input-group">
										       <label>
                                               
                                              </label>
											</div>
                                           
                                             <div class="input-group" style="margin-top:17px; ">
                                            <span class="input-group-addon">Bathroom</span>
                                            <select class="form-control" id="propertytype">
                                                <option value="" disabled selected>Select TotalFloors</option>
                                                <option>ceramic tiles</option>
                                                <option>vitrified tiles</option>
												<option>AntiSkid tiles</option>
												<option>granite tiles</option>
                                                <option>Wooden Flooring</option>
												<option>RAK/Laminated flooring</option>
												<option>WoodFinishing tiles</option>
                                            </select>
                                              </div>
                                           </div>

                            </div>  
                                       
										
                            <div class="row">
								<div class="col-sm-4">
                                             <div class="input-group">
										       <label>

                                              </label>
											</div>
                                           
                                        <div class="input-group" style="margin-top:9px;">
                                            <span class="input-group-addon">MasterBedroom</span>
                                            <select class="form-control" id="propertytype">
                                                <option value="" disabled selected>Select TotalFloors</option>
                                                <option>ceramic tiles</option>
                                                <option>vitrified tiles</option>
												<option>AntiSkid tiles</option>
												<option>granite tiles</option>
                                                <option>Wooden Flooring</option>
												<option>RAK/Laminated flooring</option>
												<option>WoodFinishing tiles</option>
                                            </select>
                                        </div>
                                </div>
								<div class="col-sm-4">
                                             <div class="input-group">
										       <label>
                                               
                                              </label>
											</div>
                                           
                                        <div class="input-group" style="margin-top:9px;">
                                            <span class="input-group-addon">Balcony</span>
                                            <select class="form-control" id="propertytype">
                                                <option value="" disabled selected>Select TotalFloors</option>
                                               <option>ceramic tiles</option>
                                                <option>vitrified tiles</option>
												<option>AntiSkid tiles</option>
												<option>granite tiles</option>
                                                <option>Wooden Flooring</option>
												<option>RAK/Laminated flooring</option>
												<option>WoodFinishing tiles</option>
                                            </select>
                                        </div>
                                </div>
								<div class="col-sm-4">
                                             <div class="input-group">
										       <label>
                                               
                                              </label>
											</div>
                                           
                                        <div class="input-group" style="margin-top:9px;">
                                            <span class="input-group-addon">OtherRooms</span>
                                            <select class="form-control" id="propertytype">
                                                <option value="" disabled selected>Select TotalFloors</option>
                                                <option>ceramic tiles</option>
                                                <option>vitrified tiles</option>
												<option>AntiSkid tiles</option>
												<option>granite tiles</option>
                                                <option>Wooden Flooring</option>
												<option>RAK/Laminated flooring</option>
												<option>WoodFinishing tiles</option>
                                            </select>
                                        </div>
                                </div>
                                          
                            </div>
				
                                    </div>
									</div>
								
                                <br />

                                <script type="text/javascript">
                                    $(function () {
                                        $('#multicheck').multiselect({
                                            includeSelectAllOption: true,
                                            enableFiltering: true,
                                            enableCaseInsensitiveFiltering: true,
                                            buttonWidth: '100%',
                                            filterPlaceholder: 'Search Amenities',
                                        });
                                    });
                                </script>
                                <script type="text/javascript">
                                    $(function () {
                                        $('#multicheck2').multiselect({
                                            includeSelectAllOption: true,
                                            enableFiltering: true,
                                            enableCaseInsensitiveFiltering: true,
                                            buttonWidth: '100%',
                                            filterPlaceholder: 'Search Furnishing',
                                        });
                                    });
                                </script>

                                
                                <br />
                               
							   
                            </div>
                        </div>

                    </div>




                </div>



                <div id="propertytypeselect2" style="display:none">
                    <div class="col-sm-6">
                        <div class="input-group">
                            <span class="input-group-addon">Plot Area</span>
                            <input type="text" class="form-control">
                        </div>
                    </div>
                    <br />
                    <br /> <br />
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="input-group">
                                <span class="input-group-addon">Open Side</span>
                                <select class="form-control" id="propertytype">
                                    <option value="" disabled selected>Select Open Sides</option>
                                    <option>1 Side Open</option>
                                    <option>2 Side Open</option>
                                    <option>3 Side Open</option>
                                    <option>4 Side Open</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="input-group">
                                <span class="input-group-addon">Total Floor Allowed</span>
                                <select class="form-control" id="sel1">
                                    <option value="" disabled selected>Select Floor Allowed</option>
                                    <option>Basement</option>
                                    <option>Ground</option>
                                    <option>Upper Ground</option>
                                    <option>1st Floor</option>
                                    <option>2nd Floor</option>
                                    <option>3rd Floor</option>
                                    <option>4th Floor</option>
                                    <option>5th Floor</option>
                                    <option>6th Floor</option>
                                    <option>7th Floor</option>
                                    <option>8th Floor</option>
                                    <option>9th Floor</option>
                                    <option>10th Floor</option>
                                    <option>11th Floor</option>
                                    <option>12th Floor</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <br />
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="input-group">
                                <span class="input-group-addon">Facing</span>
                                <select class="form-control" id="sel1">
                                    <option value="" disabled selected>Select Facing</option>
                                    <option value="nowashroom">East</option>
                                    <option>West</option>
                                    <option>North</option>
                                    <option>South</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="input-group">
                                <span class="input-group-addon">Facing Road Width</span>
                                <input type="text" class="form-control" />
                            </div>
                        </div>
                    </div>
                    <br />
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="input-group">
                                <span class="input-group-addon">Price</span>
                                <input type="number" value="" min="0" step="1" id="propprice" class="form-control"
                                    placeholder="Price">
                                <span class="input-group-addon">₹</span>
                                <span class="input-group-addon">
                                    <div class="checkbox" style="padding-left: 0px; margin:0px;">
                                        <label>
                                            <input type="checkbox" value="on"
                                                style="position: absolute;visibility: visible;" name="p_negotiable">  
                                            Negotiable
                                        </label>
                                    </div>
                                </span>
                            </div>
                            <a data-toggle="collapse" data-target="#price1" href="#price1"
                                style="float:right; font-size:smaller">More/Less Price Option</a>
                        </div>
                        <div class="col-sm-6">
                            <div class="input-group">
                                <span class="input-group input-group-addon">Price Per</span>
                                <input disabled type="text" class="form-control" value=""
                                    placeholder="Price Per Sq.Yrd" />
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div id="price1" class="panel-collapse collapse">
                            <div class="col-sm-4">
                                <div class="input-group">
                                    <span class="input-group-addon">Maintainance</span>
                                    <input type="text" class="form-control" placeholder="Enter Amount">
                                    <span class="input-group-addon">₹</span>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="input-group">
                                    <span class="input-group-addon">Brokerage</span>
                                    <input type="text" class="form-control" placeholder="Enter Amount">
                                    <span class="input-group-addon">₹</span>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="input-group">
                                    <span class="input-group-addon">Booking Amount</span>
                                    <input type="text" class="form-control" placeholder="Enter Amount">
                                    <span class="input-group-addon">₹</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <br />
                    <div class="row">
                        <div class="col-sm-12">
                            <textarea placeholder="description (50 characters)" min="50" max="60" class="form-control"
                                name="p_description"> </textarea>
                        </div>
                    </div>
                    <br />

                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h3 class="panel-title">
                                <a data-toggle="collapse" data-parent="#accordion" href="#filterPane3">Property
                                    Status</a>
                                <span class="pull-right panel-collapse-clickable" data-toggle="collapse"
                                    data-parent="#accordion" href="#filterPane3">
                                    <i class="glyphicon glyphicon-chevron-down"></i>
                                </span>
                            </h3>
                        </div>
                        <div id="filterPane3" class="panel-collapse collapse in">
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="input-group">
                                            <span class="input-group-addon">Transaction Type</span>
                                            <select class="form-control" id="propertytype">
                                                <option value="" disabled selected>Select Transaction Type</option>
                                                <option>New</option>
                                                <option>Resale</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="input-group">
                                            <span class="input-group-addon">Ownership Type</span>
                                            <select class="form-control" id="sel1">
                                                <option value="" disabled selected>Select Ownership Type</option>
                                                <option>Freehold</option>
                                                <option>Power of Attorney</option>
                                                <option>Leasehold</option>
                                                <option>Co-operative Society</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h3 class="panel-title">
                                <a data-toggle="collapse" data-parent="#accordion" href="#filterPane2">Additional
                                    Detail</a>
                                <span class="pull-right panel-collapse-clickable" data-toggle="collapse"
                                    data-parent="#accordion" href="#filterPane2">
                                    <i class="glyphicon glyphicon-chevron-down"></i>
                                </span>
                            </h3>
                        </div>
                        <div id="filterPane2" class="panel-collapse collapse in">
                            <div class="panel-body">
                                <script type="text/javascript">
                                    $(function () {
                                        $('#multicheck3').multiselect({
                                            includeSelectAllOption: true,
                                            enableFiltering: true,
                                            enableCaseInsensitiveFiltering: true,
                                            buttonWidth: '100%',
                                            filterPlaceholder: 'Search Amenities',
                                        });
                                    });
                                </script>

                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="input-group">
                                            <span class="input-group-addon">Amenities</span>
                                            <select id="multicheck3" multiple="multiple">
                                                <option value="1">Security / Fire Alarm</option>
                                                <option value="2">Centrally Air Conditioned</option>
                                                <option value="3">Lift(s)</option>
                                                <option value="4">Security Personnel</option>
                                                <option value="5">Cafeteria / Food Court</option>
                                                <option value="6">Visitors Parking</option>
                                                <option value="7">Service / Goods Lift</option>
                                                <option value="8">Maintainance Staff</option>
                                                <option value="9">Wifi</option>
                                                <option value="10">Eatrhquake Resistant</option>
                                                <option value="11">Conferance Room</option>
                                                <option value="12">Intercom facility</option>
                                                <option value="13">Fitness centre / Gym</option>
                                                <option value="14">Water Sotrage</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>

    </form>

<script>
    $(document).ready(function () {

        $("#watch-me").click(function () {
            $("#show-me:hidden").show('slow');

            $("#show-me-two").hide();

            $("#show-me-three").hide();

        });

        $("#watch-me").click(function () {

            if ($('watch-me').prop('checked') === false) {

                $('#show-me').hide();

            }

        });




        $("#see-me").click(function () {
            $("#show-me-two:hidden").show('slow');
            $("#show-me").hide();
            $("#show-me-three").hide();
        });
        $("#see-me").click(function () {
            if ($('see-me-two').prop('checked') === false) {
                $('#show-me-two').hide();
            }
        });







        $("#look-me").click(function () {
            $("#show-me-three:hidden").show('slow');
            $("#show-me").hide();
            $("#show-me-two").hide();
        });
        $("#look-me").click(function () {
            if ($('see-me-three').prop('checked') === false) {
                $('#show-me-three').hide();
            }
        });

    });

</script>
<div class="container Villas box" style="margin-top:10px;">
    <fieldset class="form-group">
        <a href="javascript:void(0)" onclick="$('#pro-image').click()">Upload Image</a>
        <input type="file" id="pro-image" name="pro-image" style="display: none;" class="form-control"  placeholder=" Upload Image"multiple>
    </fieldset>
    <div class="preview-images-zone">
        
        
        
    </div>
</div>
<div class="container Villas box">
 
  <p>PostedBy:</p>
  <form>
    <label class="radio-inline">
      <input type="radio" name="optradio" checked>Agent
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio">Owner
    </label>
	<label class="radio-inline">
      <input type="radio" name="optradio">Others
    </label>
	
	<br>
  
</div>


                       <!--for rent apartment>
			    <div class="container">
					<div class="row">
                            <div class="col-sm-3">
                                <div class="input-group">
                                    <span class="input-group input-group-addon">MonthlyRent</span>
                                    <input  type="number" class="form-control"placeholder="Enter Amount in Rs" />
                                </div>
								<div class="checkbox" style="padding-left: 10px; margin:0px;">
                                        <label>
                                            <input type="checkbox" value="on"
                                                style="position: absolute;visibility: visible;" name="p_negotiable">  
                                            Negotiable
                                        </label>
                                    </div>
                            </div>
                            <div class="col-sm-3">
                                <div class="input-group">
                                  <span class="input-group-addon">SecurityDeposit</span>
                                    <select class="form-control" id="type">
                                        <option value="" disabled selected>SecurityDeposit</option>
                                        <option value="1">00 Month</option>
                                        <option value="1">01 Month</option>
                                        <option value="1">02 Month</option>
                                        <option value="1">03 Month</option>
                                        <option value="1">04 Month</option>
                                        <option value="1">05 Month</option>
                                        <option value="1">06 Month</option>
							            <option value="2">07 Month</option>
							            <option value="2">08 Month</option>
							                            
                                    </select>
                                </div>
                            </div>
                            <div class="col-sm-3" >
                                <div class="input-group">
                                    <span class="input-group-addon">Maintainance</span>
                                    <input type="text" class="form-control" placeholder="Enter Amount in Rs">
                                    
                                </div>
                            </div>
                            <div class="col-sm-3">
                                <div class="input-group">
                                                <span class="input-group-addon">Available From</span>
												<input type="date" id="start" style="height:34px"name="trip-start" value="2018-07-22" min="2020-10-01" max="2020-12-31">
                                            </div>
                            </div>
                        </div>
                    </div>
				</div>
					
					<!-- end for rent apartment-->


















											
											
											
											
											
											
											
											
											
											
											
											
											
											
											
											
											
		
											
											
											 <!-- end Villa Code-->
											









































<script>


 $(function() {
   $("input[name='optradio']").click(function() {
     if ($("#unfurnished").is(":checked")) {
	   $("#furnishinghide").hide();
     } else {
              $("#furnishinghide").show();

     }
   });
 });

</script>



</body>




<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>


<script src="assets/js/feather-icons/feather.min.js"></script>
    <script src="assets/vendors/perfect-scrollbar/perfect-scrollbar.min.js"></script>
    <script src="assets/js/app.js"></script>
    
<script src="assets/vendors/simple-datatables/simple-datatables.js"></script>
<script src="assets/js/vendors.js"></script>

    <script src="assets/js/main.js"></script>
</html>