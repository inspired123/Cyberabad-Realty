<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Input Group - Voler Admin Dashboard</title>
    
    <link rel="stylesheet" href="assets/css/bootstrap.css">
    
    <link rel="stylesheet" href="assets/vendors/perfect-scrollbar/perfect-scrollbar.css">
    <link rel="stylesheet" href="assets/css/app.css">
    <link rel="shortcut icon" href="assets/images/favicon.svg" type="image/x-icon">
	<link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.0.3/css/font-awesome.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600|Raleway:400,700,800|Roboto:400,500,700"
        rel="stylesheet">
    <link rel="stylesheet" href="css2/style.css">
    <link rel="stylesheet" href="css2/plugins.css">
	
	
	
	


<link rel="stylesheet" href="assets/css/bootstrap.css">
    
    <link rel="stylesheet" href="assets/vendors/quill/quill.bubble.css">
    <link rel="stylesheet" href="assets/vendors/quill/quill.snow.css">

    <link rel="stylesheet" href="assets/vendors/perfect-scrollbar/perfect-scrollbar.css">
    <link rel="stylesheet" href="assets/css/app.css">
    <link rel="shortcut icon" href="assets/images/favicon.svg" type="image/x-icon">
	<title>Document</title>
    <style>
        * {
            margin: 0;
            padding: 0
        }

        html {
            height: 100%
        }

        #grad1 {
            background-color: : #9C27B0;
           
        }

        #msform {
            text-align: center;
            position: relative;
            margin-top: 20px
        }

        #msform fieldset .form-card {
            background: white;
            border: 0 none;
            border-radius: 0px;
            box-shadow: 0 2px 2px 2px rgba(0, 0, 0, 0.2);
            padding: 20px 40px 30px 40px;
            box-sizing: border-box;
            width: 94%;
            margin: 0 3% 20px 3%;
            position: relative
        }

        #msform fieldset {
            background: white;
            border: 0 none;
            border-radius: 0.5rem;
            box-sizing: border-box;
            width: 100%;
            margin: 0;
            padding-bottom: 20px;
            position: relative
        }

        #msform fieldset:not(:first-of-type) {
            display: none
        }

        #msform fieldset .form-card {
            text-align: left;
            color: #9E9E9E
        }

        #msform input,
        #msform textarea {
            padding: 0px 8px 4px 8px;
            border: none;
            border-bottom: 1px solid #ccc;
            border-radius: 0px;
            margin-bottom: 25px;
            margin-top: 2px;
            width: 100%;
            box-sizing: border-box;
            font-family: montserrat;
            color: #2C3E50;
            font-size: 16px;
            letter-spacing: 1px
        }

        #msform input:focus,
        #msform textarea:focus {
            -moz-box-shadow: none !important;
            -webkit-box-shadow: none !important;
            box-shadow: none !important;
            border: none;
            font-weight: bold;
            border-bottom: 2px solid skyblue;
            outline-width: 0
        }

        #msform .action-button {
            width: 100px;
            background: skyblue;
            font-weight: bold;
            color: white;
            border: 0 none;
            border-radius: 0px;
            cursor: pointer;
            padding: 10px 5px;
            margin: 10px 5px
        }

        #msform .action-button:hover,
        #msform .action-button:focus {
            box-shadow: 0 0 0 2px white, 0 0 0 3px skyblue
        }

        #msform .action-button-previous {
            width: 100px;
            background: #616161;
            font-weight: bold;
            color: white;
            border: 0 none;
            border-radius: 0px;
            cursor: pointer;
            padding: 10px 5px;
            margin: 10px 5px
        }

        #msform .action-button-previous:hover,
        #msform .action-button-previous:focus {
            box-shadow: 0 0 0 2px white, 0 0 0 3px #616161
        }

        select.list-dt {
            border: none;
            outline: 0;
            border-bottom: 1px solid #ccc;
            padding: 2px 5px 3px 5px;
            margin: 2px
        }

        select.list-dt:focus {
            border-bottom: 2px solid skyblue
        }

        .card {
            z-index: 0;
            border: none;
            border-radius: 0.5rem;
            position: relative
        }

        .fs-title {
            font-size: 25px;
            color: #2C3E50;
            margin-bottom: 10px;
            font-weight: bold;
            text-align: left
        }

        #progressbar {
            margin-bottom: 30px;
            overflow: hidden;
            color: lightgrey
        }

        #progressbar .active {
            color: #000000
        }

        #progressbar li {
            list-style-type: none;
            font-size: 12px;
            width: 16.6%;
            float: left;
            position: relative
        }

        #progressbar #account:before {
            font-family: FontAwesome;
            content: "\f023"
        }

        #progressbar #personal:before {
            font-family: FontAwesome;
            content: "\f007"
        }

        #progressbar #payment:before {
            font-family: FontAwesome;
            content: "\f09d"
        }

        #progressbar #confirm:before {
            font-family: FontAwesome;
            content: "\f00c"
        }

        #progressbar li:before {
            width: 50px;
            height: 50px;
            line-height: 45px;
            display: block;
            font-size: 18px;
            color: #ffffff;
            background: lightgray;
            border-radius: 50%;
            margin: 0 auto 10px auto;
            padding: 2px
        }

        #progressbar li:after {
            content: '';
            width: 100%;
            height: 2px;
            background: lightgray;
            position: absolute;
            left: 0;
            top: 25px;
            z-index: -1
        }

        #progressbar li.active:before,
        #progressbar li.active:after {
            background: skyblue
        }

        .radio-group {
            position: relative;
            margin-bottom: 25px
        }

        .radio {
            display: inline-block;
            width: 204;
            height: 104;
            border-radius: 0;
            background: lightblue;
            box-shadow: 0 2px 2px 2px rgba(0, 0, 0, 0.2);
            box-sizing: border-box;
            cursor: pointer;
            margin: 8px 2px
        }

        .radio:hover {
            box-shadow: 2px 2px 2px 2px rgba(0, 0, 0, 0.2)
        }

        .radio.selected {
            opacity:0.5;
            border:1px solid red;
            box-shadow: 1px 1px 2px 2px rgba(0, 0, 0, 0.8)
            
        }

        .fit-image {
            width: 100%;
            object-fit: cover
        }
		input[type="checkbox"][id^="cb"] {
  display: none;
}

label {
  border: 1px solid #fff;
  
  display: block;
  position: relative;
  margin: 10px;
  cursor: pointer;
  -webkit-touch-callout: none;
  -webkit-user-select: none;
  -khtml-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
}

label::before {
  background-color: white;
  color: white;
  content: " ";
  display: block;
  border-radius: 50%;
  border: 1px solid grey;
  position: absolute;
  top: -5px;
  left: -5px;
  width: 25px;
  height: 25px;
  text-align: center;
  line-height: 28px;
  transition-duration: 0.4s;
  transform: scale(0);
}

label img {
  height: 100px;
  width: 100px;
  transition-duration: 0.2s;
  transform-origin: 50% 50%;
}





:checked+label img {
  transform: scale(0.9);
  box-shadow: 0 0 5px #333;
  z-index: -1;
}	
.form-check-input {
    width: 1.25em !important;
    height: 1.25em !important;
    margin-top: 0.125em !important;
    vertical-align: top !important;
    
    background-repeat: no-repeat !important;
    background-position: center !important;
    background-size: contain !important;
    border: 1px solid rgba(0, 0, 0, 0.25) !important;
    -webkit-appearance: none !important;
    -moz-appearance: none !important;
    appearance: none !important;
    -webkit-print-color-adjust: exact !important;
    color-adjust: exact !important;
    transition: background-color 0.15s ease-in-out, background-position 0.15s ease-in-out, border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
}
    </style>
</head>
<body>
    <div id="app">
        <div id="sidebar" class='active'>
            <div class="sidebar-wrapper active">
    <div class="sidebar-header">
        <img src="assets/images/logo.svg" alt="" srcset="">
    </div>
    <div class="sidebar-menu">
        <ul class="menu">
            
            
                <li class='sidebar-title'>Main Menu</li>
            
            
            
                <li class="sidebar-item  ">
                    <a href="index.html" class='sidebar-link'>
                        <i data-feather="home" width="20"></i> 
                        <span>Dashboard</span>
                    </a>
                    
                </li>

            
            
            
                <li class="sidebar-item  has-sub">
                    <a href="#" class='sidebar-link'>
                        <i data-feather="triangle" width="20"></i> 
                        <span>Components</span>
                    </a>
                    
                    <ul class="submenu ">
                        
                        <li>
                            <a href="component-alert.html">Alert</a>
                        </li>
                        
                        <li>
                            <a href="component-badge.html">Badge</a>
                        </li>
                        
                        <li>
                            <a href="component-breadcrumb.html">Breadcrumb</a>
                        </li>
                        
                        <li>
                            <a href="component-buttons.html">Buttons</a>
                        </li>
                        
                        <li>
                            <a href="component-card.html">Card</a>
                        </li>
                        
                        <li>
                            <a href="component-carousel.html">Carousel</a>
                        </li>
                        
                        <li>
                            <a href="component-dropdowns.html">Dropdowns</a>
                        </li>
                        
                        <li>
                            <a href="component-list-group.html">List Group</a>
                        </li>
                        
                        <li>
                            <a href="component-modal.html">Modal</a>
                        </li>
                        
                        <li>
                            <a href="component-navs.html">Navs</a>
                        </li>
                        
                        <li>
                            <a href="component-pagination.html">Pagination</a>
                        </li>
                        
                        <li>
                            <a href="component-progress.html">Progress</a>
                        </li>
                        
                        <li>
                            <a href="component-spinners.html">Spinners</a>
                        </li>
                        
                        <li>
                            <a href="component-tooltips.html">Tooltips</a>
                        </li>
                        
                    </ul>
                    
                </li>

            
            
            
                <li class="sidebar-item  has-sub">
                    <a href="#" class='sidebar-link'>
                        <i data-feather="briefcase" width="20"></i> 
                        <span>Extra Components</span>
                    </a>
                    
                    <ul class="submenu ">
                        
                        <li>
                            <a href="component-extra-avatar.html">Avatar</a>
                        </li>
                        
                        <li>
                            <a href="component-extra-divider.html">Divider</a>
                        </li>
                        
                    </ul>
                    
                </li>

            
            
            
                <li class="sidebar-item  has-sub">
                    <a href="#" class='sidebar-link'>
                        <i data-feather="file-text" width="20"></i> 
                        <span>Property</span>
                    </a>
                    
                    <ul class="submenu ">
                        
                        <li>
                            <a href="form-element-input.html"style="font-size:15px;" >PropertyList</a>
                        </li>
                        
                        <li>
                            <a href="form-element-input-group.html" style="font-size:15px;">Add Property</a>
                        </li>
                        
                        <li>
                            <a href="form-element-select.html" style="font-size:15px;">Delete Property</a>
                        </li>
                        
                        <li>
  <a href="form-element-radio.html" style="font-size:15px;">Property Detail</a>
                        </li>
                        
                        <li>
                            <a href="form-element-checkbox.html" style="font-size:15px;">Checkbox</a>
                        </li>
                        
                        <li>
                            <a href="form-element-textarea.html"style="font-size:15px;">Textarea</a>
                        </li>
                        
                    </ul>
                    
                </li>
            
            
            
                <li class="sidebar-item  ">
                    <a href="form-layout.html" class='sidebar-link'>
                        <i data-feather="layout" width="20"></i> 
                        <span>Form Layout</span>
                    </a>
                    
                </li>

            
            
            
                <li class="sidebar-item  ">
                    <a href="form-editor.html" class='sidebar-link'>
                        <i data-feather="layers" width="20"></i> 
                        <span>Form Editor</span>
                    </a>
                    
                </li>

            
            
            
                <li class="sidebar-item  ">
                    <a href="table.html" class='sidebar-link'>
                        <i data-feather="grid" width="20"></i> 
                        <span>Table</span>
                    </a>
                    
                </li>

            
            
            
                <li class="sidebar-item  ">
                    <a href="table-datatable.html" class='sidebar-link'>
                        <i data-feather="file-plus" width="20"></i> 
                        <span>Datatable</span>
                    </a>
                    
                </li>
				<li class="sidebar-item active ">
                    <a href="{{url('/')}}/addpropertyfinal" class='sidebar-link'>
                        <i data-feather="file-plus" width="20"></i> 
                        <span>Add property</span>
                    </a>
                    
                </li>

            
            
            
                <li class='sidebar-title'>Extra UI</li>
            
            
            
                <li class="sidebar-item  has-sub">
                    <a href="#" class='sidebar-link'>
                        <i data-feather="user" width="20"></i> 
                        <span>Widgets</span>
                    </a>
                    
                    <ul class="submenu ">
                        
                        <li>
                            <a href="ui-chatbox.html">Chatbox</a>
                        </li>
                        
                        <li>
                            <a href="ui-pricing.html">Pricing</a>
                        </li>
                        
                        <li>
                            <a href="ui-todolist.html">To-do List</a>
                        </li>
                        
                    </ul>
                    
                </li>

            
            
            
                <li class="sidebar-item  has-sub">
                    <a href="#" class='sidebar-link'>
                        <i data-feather="trending-up" width="20"></i> 
                        <span>Charts</span>
                    </a>
                    
                    <ul class="submenu ">
                        
                        <li>
                            <a href="ui-chart-chartjs.html">ChartJS</a>
                        </li>
                        
                        <li>
                            <a href="ui-chart-apexchart.html">Apexchart</a>
                        </li>
                        
                    </ul>
                    
                </li>

            
            
            
                <li class='sidebar-title'>Pages</li>
            
            
            
                <li class="sidebar-item  has-sub">
                    <a href="#" class='sidebar-link'>
                        <i data-feather="user" width="20"></i> 
                        <span>Authentication</span>
                    </a>
                    
                    <ul class="submenu ">
                        
                        <li>
                            <a href="auth-login.html">Login</a>
                        </li>
                        
                        <li>
                            <a href="auth-register.html">Register</a>
                        </li>
                        
                        <li>
                            <a href="auth-forgot-password.html">Forgot Password</a>
                        </li>
                        
                    </ul>
                    
                </li>

            
            
            
                <li class="sidebar-item  has-sub">
                    <a href="#" class='sidebar-link'>
                        <i data-feather="alert-circle" width="20"></i> 
                        <span>Errors</span>
                    </a>
                    
                    <ul class="submenu ">
                        
                        <li>
                            <a href="error-403.html">403</a>
                        </li>
                        
                        <li>
                            <a href="error-404.html">404</a>
                        </li>
                        
                        <li>
                            <a href="error-500.html">500</a>
                        </li>
                        
                    </ul>
                    
                </li>

            
            
         
        </ul>
    </div>
    <button class="sidebar-toggler btn x"><i data-feather="x"></i></button>
</div>
        </div>
        <div id="main">
            <nav class="navbar navbar-header navbar-expand navbar-light">
                <a class="sidebar-toggler" href="#"><span class="navbar-toggler-icon"></span></a>
                <button class="btn navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                    aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav d-flex align-items-center navbar-light ml-auto">
                        <li class="dropdown nav-icon">
                            <a href="#" data-toggle="dropdown" class="nav-link  dropdown-toggle nav-link-lg nav-link-user">
                                <div class="d-lg-inline-block">
                                    <i data-feather="bell"></i>
                                </div>
                            </a>
                            <div class="dropdown-menu dropdown-menu-right dropdown-menu-large">
                                <h6 class='py-2 px-4'>Notifications</h6>
                                <ul class="list-group rounded-none">
                                    <li class="list-group-item border-0 align-items-start">
                                        <div class="avatar bg-success mr-3">
                                            <span class="avatar-content"><i data-feather="shopping-cart"></i></span>
                                        </div>
                                        <div>
                                            <h6 class='text-bold'>New Order</h6>
                                            <p class='text-xs'>
                                                An order made by Ahmad Saugi for product Samsung Galaxy S69
                                            </p>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <li class="dropdown nav-icon mr-2">
                            <a href="#" data-toggle="dropdown" class="nav-link  dropdown-toggle nav-link-lg nav-link-user">
                                <div class="d-lg-inline-block">
                                    <i data-feather="mail"></i>
                                </div>
                            </a>
                            <div class="dropdown-menu dropdown-menu-right">
                                <a class="dropdown-item" href="#"><i data-feather="user"></i> Account</a>
                                <a class="dropdown-item active" href="#"><i data-feather="mail"></i> Messages</a>
                                <a class="dropdown-item" href="#"><i data-feather="settings"></i> Settings</a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="#"><i data-feather="log-out"></i> Logout</a>
                            </div>
                        </li>
                        <li class="dropdown">
                            <a href="#" data-toggle="dropdown" class="nav-link dropdown-toggle nav-link-lg nav-link-user">
                                <div class="avatar mr-1">
                                    <img src="assets/images/avatar/avatar-s-1.png" alt="" srcset="">
                                </div>
                                <div class="d-none d-md-block d-lg-inline-block">Hi, Saugi</div>
                            </a>
                            <div class="dropdown-menu dropdown-menu-right">
                                <a class="dropdown-item" href="#"><i data-feather="user"></i> Account</a>
                                <a class="dropdown-item active" href="#"><i data-feather="mail"></i> Messages</a>
                                <a class="dropdown-item" href="#"><i data-feather="settings"></i> Settings</a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="#"><i data-feather="log-out"></i> Logout</a>
                            </div>
                        </li>
                    </ul>
                </div>
            </nav>
            
<!-- MultiStep Form -->
    <div class="container-fluid" id="grad1">
        <div class="row justify-content-center mt-0" style="margin-top:12px">
            <div class="col-12 col-sm-12 col-md-12 col-lg-12 text-center p-0 mt-3 mb-2">
                <div class="card px-0 pt-4 pb-0 mt-3 mb-3" >
                    <h2><strong>Sign Up Your User Account</strong></h2>
                    <p>Fill all form field to go to next step</p>
                    <div class="row">
                        <div class="col-md-12 mx-0">
                            <form id="msform">
                                <!-- progressbar -->
                                <ul id="progressbar">
                                    <li class="active" id="account"><strong>Property Type</strong></li>
                                    <li id="personal"><strong>Property Details</strong></li>
                                    <li id="payment"><strong>Property Features</strong></li>
                                    <li id="confirm"><strong>Additional Information</strong></li>
									<li id="payment"><strong>Location</strong></li>
                                    <li id="confirm"><strong>Finish</strong></li>

                                </ul> <!-- fieldsets -->

                                <fieldset>
                                    <div class="form-card">
                                        <!-- <h2 class="fs-title">Payment Information</h2> -->
                                        <div class="radio-group">
                                            <div class='radio' data-value="credit"><img
                                                    src="{{url('/')}}/img/aprtment.jpg"
                                                    width="200px" height="80px">
                                            </div>
                                            <div class='radio' data-value="paypal"><img
                                                    src="{{url('/')}}/img/villa.jpg"
                                                    width="200px" height="80px">
                                            </div>
                                            <div class='radio' data-value="paypal"><img
                                                    src="{{url('/')}}/img/independent.jpg"
                                                    width="200px" height="80px">
                                            </div>
                                            <div class='radio' data-value="paypal"><img
                                                    src="{{url('/')}}/img/farmhouse.jpg"
                                                    width="200px" height="80px">
                                            </div>
											<div class='radio' data-value="paypal"><img
                                                    src="{{url('/')}}/img/farmlands.jpg"
                                                    width="200px" height="80px">
                                            </div>
											<div class='radio' data-value="paypal"><img
                                                    src="{{url('/')}}/img/warehouse.jpg"
                                                    width="200px" height="80px">
                                            </div>
											<br>
                                        </div>

                                    </div> <input type="button" name="next" class="next action-button"
                                        value="Next Step" />
                                </fieldset>
                                <fieldset>
                                    <div class="form-card">
                                        <h2 class="fs-title">Property Details</h2>

                                        <div>
                                            <div class="submit-property__block">
                                                

                                                <div class="row">
            <div class="form-group col-md-12">
                <div class="input-group">
                    <div class="btn-group" data-toggle="buttons">
                        <label class="btn btn-primary">
                            <input type="radio" name="options" > Sale
                        </label>

                        <label class="btn btn-primary">
                            <input type="radio" name="options"> Rent
                        </label>
                    </div>
                </div>
            </div>
        </div><br><!-- .submit-property__group -->
<div class="container">
  <div class="form-row">
    <div class="form-group col-md-4">
      <label for="inputState">Bedrooms</label>
      <select id="inputState" class="form-control"style="
    border-radius: 50px !important;">
        <option selected>Select Bedrooms</option>
		<option>1</option>
        <option>2</option>
		<option>3</option>
		<option>4</option>
		<option>5</option>
      </select>
    </div>
	<div class="form-group col-md-4">
      <label for="inputState">Balconies</label>
      <select id="inputState" class="form-control"style="
    border-radius: 50px !important;">
        <option selected>Select Balconies</option>
		<option>1</option>
        <option>2</option>
		<option>3</option>
		<option>4</option>
		<option>5</option>
      </select>
    </div>
	<div class="form-group col-md-4">
      <label for="inputState">Bathrooms</label>
      <select id="inputState" class="form-control"style="
    border-radius: 50px !important;">
        <option selected>Select Bathrooms</option>
		<option>1</option>
        <option>2</option>
		<option>3</option>
		<option>4</option>
		<option>5</option>
      </select>
    </div>
	</div>
</div>
<div class="container-fluid">
	<div class="form-row">
    <div class="form-group col-md-12">
      <label for="inputPassword4"style="color:black;">Area</label>
	 </div>
	 </div>
<div class="form-row">
    <div class="form-group col-md-2">
      <label for="inputPassword4"style="color:black;">Total Area</label>
	  <input type="text" class="form-control" id="inputCity"style="
    border: 1px solid #ccc;
    border-radius: 50px !important;">
	</div>
	  <div class="form-group col-md-2" >
      <label for="inputState"></label>
      <select id="inputState" class="form-control"style="margin: 30px 0px 0px 0px;">
        <option selected>sqyard</option>
		<option>sqft</option>
        
		
      </select>
    
	 </div>
	 <div class="form-group col-md-2">
      <label for="inputPassword4"style="color:black;">Carpet Area</label>
	  <input type="text" class="form-control" id="inputCity"style="
    border: 1px solid #ccc;
    border-radius: 50px !important;">
	</div>
	  <div class="form-group col-md-2" >
      <label for="inputState"></label>
      <select id="inputState" class="form-control"style="margin: 30px 0px 0px 0px;">
        <option selected>sqyard</option>
		
        <option>sqft</option>
		
      </select>
    
	 </div>
	 <div class="form-group col-md-2">
      <label for="inputPassword4"style="color:black;">Buildup Area</label>
	  <input type="text" class="form-control" id="inputCity"style="
    border: 1px solid #ccc;
    border-radius: 50px !important;">
	</div>
	  <div class="form-group col-md-2" >
      <label for="inputState"></label>
      <select id="inputState" class="form-control"style="margin: 30px 0px 0px 0px;">
        <option selected>sqyard</option>
		
        <option>sqft</option>
		
      </select>
    
	 </div>
	</div>
</div>
<div class="container">
	<div class="form-row">
    <div class="form-group col-md-12">
      <label for="inputPassword4"style="color:black;">Additional Rooms</label>
	 </div>
	 </div>
	 <div class="form-row"style="
    padding-left: 20px;">
      <div class="form-group col-md-3">
    <div class="form-check">
      <input class="form-check-input" type="checkbox" id="gridCheck">
      <label class="form-check-label" for="gridCheck">
        Servent Room
      </label>
    </div>
  </div>
  <div class="form-group col-md-3">
    <div class="form-check">
      <input class="form-check-input" type="checkbox" id="gridCheck">
      <label class="form-check-label" for="gridCheck">
        Study Room
      </label>
    </div>
  </div>
  <div class="form-group col-md-3">
    <div class="form-check">
      <input class="form-check-input" type="checkbox" id="gridCheck">
      <label class="form-check-label" for="gridCheck">
        Store Room
      </label>
    </div>
  </div>
  <div class="form-group col-md-3">
    <div class="form-check">
      <input class="form-check-input" type="checkbox" id="gridCheck">
      <label class="form-check-label" for="gridCheck">
        Pooja Room
      </label>
    </div>
  </div>
    </div>
	</div>

<!--<div class="container">
	<div class="form-row">
    <div class="form-group col-md-12">
      <label for="inputPassword4"style="color:black;">Additional Rooms</label>
	 </div>
	 </div>
	 <div class="form-row">
      <div class="form-group col-md-2">
    <div class="form-check">
      <input type="checkbox" id="cb1" />
                                    <label for="cb1">
									<p>StudyRoom</p>
									<img src="E:\admin-panel\admin-panel\docs\img\icons8-study-100.png" /></label>
    </div>
  </div>
  <div class="form-group col-md-2">
    <div class="form-check">
      <input type="checkbox" id="cb2" />
                                    <label for="cb2">
									<p>StudyRoom</p>
									<img src="E:\admin-panel\admin-panel\docs\img\icons8-study-100.png" /></label>
    </div>
  </div>
  <div class="form-group col-md-2">
    <div class="form-check">
      <input type="checkbox" id="cb3" />
                                    <label for="cb3">
									<p>StudyRoom</p>
									<img src="E:\admin-panel\admin-panel\docs\img\icons8-study-100.png" /></label>
    </div>
  </div>
  <div class="form-group col-md-2">
    <div class="form-check">
      <input type="checkbox" id="cb4" />
                                    <label for="cb4">
									<p>StudyRoom</p>
									<img src="E:\admin-panel\admin-panel\docs\img\icons8-study-100.png" /></label>
    </div>
  </div>
    </div>
	</div>-->
	
	<div class="container">
<div class="form-row">
    <div class="form-group col-md-3">
      <label for="inputPassword4"style="color:black;">price</label>
	  <input type="text" class="form-control" id="inputCity"style="
    border: 1px solid #ccc;
    border-radius: 50px !important;">
	</div>
	  <div class="form-group col-md-3" >
      <label for="inputState"></label>
      <select id="inputState" class="form-control"style="margin: 30px 0px 0px 0px;">
        <option selected>Rs/Sqyard</option>
        <option>Rs/Sqft</option>
		
      </select>
    
	 </div>
	 <div class="form-group col-md-3">
      <label for="inputState">Negotiatible</label>
      <select id="inputState" class="form-control">
        <option selected>Yes</option>
        <option>No</option>
		
      </select>
    
	 </div>
	 <div class="form-group col-md-3">
      <label for="inputPassword4"style="color:black;">Booking Amount</label>
	  <input type="text" class="form-control" placeholder="Rs/-" id="inputCity"style="
    border: 1px solid #ccc;
    border-radius: 50px !important;">
	</div>
	</div>
</div>


<div class="container">
<div class="form-row">
    <div class="form-group col-md-2">
      <label for="inputPassword4"style="color:black;">Price</label>
	  <input type="text" class="form-control" id="inputCity"style="
    border: 1px solid #ccc;
    border-radius: 50px !important;">
	</div>
	  <div class="form-group col-md-2" >
      <label for="inputState"></label>
      <select id="inputState" class="form-control"style="margin: 30px 0px 0px 0px;">
        <option selected>Rs/Sqyard</option>
        <option>Rs/Sqft</option>
		
      </select>
    
	 </div>
	 <div class="form-group col-md-3">
      <label for="inputState">Negotiatible</label>
      <select id="inputState" class="form-control">
        <option selected>Yes</option>
        <option>No</option>
		
      </select>
    
	 </div>
	 <div class="form-group col-md-3">
      <label for="inputPassword4"style="color:black;">Security Deposit</label>
	  <input type="text" class="form-control" placeholder="Rs/-" id="inputCity"style="
    border: 1px solid #ccc;
    border-radius: 50px !important;">
	</div>
	</div>
	<div class="form-row">
	<div class="form-group col-md-3">
      <label for="inputPassword4"style="color:black;">Monthly maintenance</label>
	  <input type="text" class="form-control" placeholder="Rs/-" id="inputCity"style="
    border: 1px solid #ccc;
    border-radius: 50px !important;">
	</div>
	<div class="form-group col-md-3">
      <label for="inputPassword4"style="color:black;">Available from</label>
	  <input type="date" class="form-control" id="birthday" name="birthday"style="
    border: 1px solid #ccc;
    border-radius: 50px !important;">
	</div>
	</div>
</div>

<div class="container">
	<div class="form-row">
    <div class="form-group col-md-12">
      <label for="inputPassword4"style="color:black;">Price Include</label>
	 </div>
	 </div>
	 <div class="form-row"style="
    padding-left: 20px;">
      <div class="form-group col-md-3">
    <div class="form-check">
      <input class="form-check-input" type="checkbox" id="gridCheck">
      <label class="form-check-label" for="gridCheck">
        Car parking
      </label>
    </div>
  </div>
  <div class="form-group col-md-3">
    <div class="form-check">
      <input class="form-check-input" type="checkbox" id="gridCheck">
      <label class="form-check-label" for="gridCheck">
        Club membership
      </label>
    </div>
  </div>
  <div class="form-group col-md-3">
    <div class="form-check">
      <input class="form-check-input" type="checkbox" id="gridCheck">
      <label class="form-check-label" for="gridCheck">
        Registration
      </label>
    </div>
  </div>
  
    </div>
	</div>

<div class="container">
<div class="form-row">	
	<div class="form-group col-md-12">
      <label for="inputPassword4"style="color:black;">Property Status</label>
	 </div>
	 </div>
	 <div class="form-row"style="
    padding-left: 20px;">
      <div class="form-group col-md-3">
    <div class="form-check">
      <input class="form-check-input" type="radio" name="gridRadios" id="gridRadios1">
      <label class="form-check-label" for="gridRadios1">
        Ready to move
      </label>
    </div>
  </div>
  <div class="form-group col-md-3">
    <div class="form-check">
      <input class="form-check-input" type="radio" name="gridRadios" id="gridRadios2">
      <label class="form-check-label" for="gridRadios2">
        Under Construction
      </label>
    </div>
  </div>
  
  
  </div>
</div>

<div class="container">
<div class="form-row">
    <div class="form-group col-md-4">
      <label for="inputState">Age</label>
      <select id="inputState" class="form-control">
        <option selected>Select Property Age</option>
		<option>1</option>
        <option>2</option>
		<option>3</option>
		<option>4</option>
		<option>5</option>
      </select>
    </div>
	  <div class="form-group col-md-4">
      <label for="inputState">Transaction Type</label>
      <select id="inputState" class="form-control">
        <option selected>Type</option>
		<option>New</option>
        <option>Resale</option>
		
      </select>
    
	 </div>
	</div>
</div>
<div class="container">
<div class="form-row">
    <div class="form-group col-md-4">
      <label for="inputPassword4"style="color:black;">Possession Date</label>
	  <input type="date" class="form-control" id="birthday" name="birthday"style="
	  border: 1px solid #ccc;
    border-radius: 50px !important;">
	</div>
	  <div class="form-group col-md-4">
      <label for="inputState">Transaction Type</label>
      <select id="inputState" class="form-control">
        <option selected>Type</option>
		<option>New</option>
        <option>Resale</option>
		
      </select>
    
	 </div>
	</div>
</div>
<div class="container">
<div class="form-row">
    <div class="form-group col-md-12">
      <label for="inputCity">Description</label>

                            <div class="form-group has-icon-left">
                                <div class="position-relative">
									<div class="card-body"style="padding:4px;">
									<div id="full"style="padding: 0px 0px 70px 0px;">
										
									</div>
									</div>
                                    <!--<div class="form-control-icon">
                                        <i data-feather="lock"></i>
                                    </div>-->
                                </div>
                            </div>
                        </div>    
</div>

</div>








	
</div>


                                            

                                        </div>




                                    </div> <input type="button" name="previous" class="previous action-button-previous"
                                        value="Previous" /> <input type="button" name="make_payment"
                                        class="next action-button" value="Next Step" />
                                </fieldset>
                                <fieldset>
                                    <div class="form-card">

                                        <div class="submit-property__block">
                                            <h3 class="submit-property__headline">Property Features</h3>
											<div class="container">
	<div class="form-row">
    <div class="form-group col-md-12">
      <label for="inputPassword4"style="color:black;">Furnishing Status</label>
	 </div>
	 </div>
	 <div class="form-row">
      <div class="form-group col-md-3">
    <div class="form-check">
      <input class="form-check-input" type="radio" name="gridRadios" id="gridRadios1">
      <label class="form-check-label" for="gridRadios1">
        Unfurnished
      </label>
    </div>
  </div>
  <div class="form-group col-md-3">
    <div class="form-check"style="
    padding-left: 20px;">
      <input class="form-check-input" type="radio" name="gridRadios" id="gridRadios2">
      <label class="form-check-label" for="gridRadios2">
        Fully Furnished
      </label>
    </div>
  </div>
  <div class="form-group col-md-3">
    <div class="form-check">
      <input class="form-check-input" type="radio" name="gridRadios" id="gridRadios3">
      <label class="form-check-label" for="gridRadios3">
        Semi Furnished
      </label>
    </div>
  </div>
  
  </div>
</div>
<div class="container">
<div class="form-row">
    <div class="form-group col-md-12">
      <label for="inputState"style="color:black;">Fully Furnished Fields</label>
	</div>
</div>
<div class="form-row">
	<div class="form-group col-md-3">
	<label for="inputState">Bed no's</label>
      <select id="inputState" class="form-control">
        <option selected>Bed no's</option>
		<option>1</option>
        <option>2</option>
		<option>3</option>
		<option>4</option>
		<option>5</option>
      </select>
    </div>
	<div class="form-group col-md-3">
	<label for="inputState">Tv's</label>
      <select id="inputState" class="form-control">
        <option selected>Tv's</option>
		<option>1</option>
        <option>2</option>
		<option>3</option>
		<option>4</option>
		<option>5</option>
      </select>
    </div>
	<div class="form-group col-md-3">
	<label for="inputState">Greesar</label>
      <select id="inputState" class="form-control">
        <option selected>Greesar</option>
		<option>1</option>
        <option>2</option>
		<option>3</option>
		<option>4</option>
		<option>5</option>
      </select>
    </div>
	<div class="form-group col-md-3">
	<label for="inputState">Ac's</label>
      <select id="inputState" class="form-control">
        <option selected>Ac's</option>
		<option>1</option>
        <option>2</option>
		<option>3</option>
		<option>4</option>
		<option>5</option>
      </select>
    </div>
	</div>
</div>
<div class="container">
<div class="form-row">
    <div class="form-group col-md-12">
      <label for="inputPassword4"style="color:black;">Additional Furnishing</label>
	</div>
</div>
	<div class="form-row">
    <div class="form-group col-md-3">
    <div class="form-check">
      <input class="form-check-input" type="checkbox" id="gridCheck">
      <label class="form-check-label" for="gridCheck">
        Sofa
      </label>
    </div>
  </div>
  <div class="form-group col-md-3">
    <div class="form-check">
      <input class="form-check-input" type="checkbox" id="gridCheck">
      <label class="form-check-label" for="gridCheck">
        Refrigirator
      </label>
    </div>
  </div>
  <div class="form-group col-md-3">
    <div class="form-check">
      <input class="form-check-input" type="checkbox" id="gridCheck">
      <label class="form-check-label" for="gridCheck">
        Gas Connection
      </label>
    </div>
  </div>
  <div class="form-group col-md-3">
    <div class="form-check">
      <input class="form-check-input" type="checkbox" id="gridCheck">
      <label class="form-check-label" for="gridCheck">
        Dining Table
      </label>
    </div>
  </div>
  
  <div class="form-group col-md-3">
    <div class="form-check">
      <input class="form-check-input" type="checkbox" id="gridCheck">
      <label class="form-check-label" for="gridCheck">
        Micro Wave
      </label>
    </div>
  </div>
  <div class="form-group col-md-3">
    <div class="form-check">
      <input class="form-check-input" type="checkbox" id="gridCheck">
      <label class="form-check-label" for="gridCheck">
        Wshing Machine
      </label>
    </div>
  </div>
    </div>
	</div>
	<div class="container">
<div class="form-row">
    <div class="form-group col-md-12">
      <label for="inputPassword4"style="color:black;">Amities</label>
	</div>
</div>
	<div class="form-row">
    <div class="form-group col-md-3">
    <div class="form-check">
      <input class="form-check-input" type="checkbox" id="gridCheck">
      <label class="form-check-label" for="gridCheck">
        Car parking
      </label>
    </div>
  </div>
  <div class="form-group col-md-3">
    <div class="form-check">
      <input class="form-check-input" type="checkbox" id="gridCheck">
      <label class="form-check-label" for="gridCheck">
        Lift
      </label>
    </div>
  </div>
  <div class="form-group col-md-3">
    <div class="form-check">
      <input class="form-check-input" type="checkbox" id="gridCheck">
      <label class="form-check-label" for="gridCheck">
        Power backup
      </label>
    </div>
  </div>
  <div class="form-group col-md-3">
    <div class="form-check">
      <input class="form-check-input" type="checkbox" id="gridCheck">
      <label class="form-check-label" for="gridCheck">
        Security 24*7
      </label>
    </div>
  </div>
  <div class="form-group col-md-3">
    <div class="form-check">
      <input class="form-check-input" type="checkbox" id="gridCheck">
      <label class="form-check-label" for="gridCheck">
       Swimming pool
      </label>
    </div>
  </div>
  
  
  
  <div class="form-group col-md-3">
    <div class="form-check">
      <input class="form-check-input" type="checkbox" id="gridCheck">
      <label class="form-check-label" for="gridCheck">
        Gym
      </label>
    </div>
  </div>
  <div class="form-group col-md-3">
    <div class="form-check">
      <input class="form-check-input" type="checkbox" id="gridCheck">
      <label class="form-check-label" for="gridCheck">
        Landscope garden
      </label>
    </div>
  </div>
    </div>
	</div>
	<div class="container">
<div class="form-row">
    <div class="form-group col-md-4">
      <label for="inputState">Car Parking</label>
      <select id="inputState" class="form-control">
        <option selected>Covered</option>
		<option>1</option>
        <option>2</option>
		<option>3</option>
		<option>4</option>
		<option>5</option>
      </select>
    </div>
	<div class="form-group col-md-4">
      <label for="inputState">Opened</label>
      <select id="inputState" class="form-control">
        <option selected>Opened</option>
		<option>1</option>
        <option>2</option>
		<option>3</option>
		<option>4</option>
		<option>5</option>
      </select>
    </div>
	</div>
</div>
<div class="container">
<div class="form-row">
    <div class="form-group col-md-12">
      <label for="inputState">Property Details</label>
	</div>
</div>
<div class="form-row">
	<div class="form-group col-md-3">
      <select id="inputState" class="form-control">
        <option selected>Floor no</option>
		<option>1</option>
        <option>2</option>
		<option>3</option>
		<option>4</option>
		<option>5</option>
      </select>
    </div>
	<div class="form-group col-md-3">
      <select id="inputState" class="form-control">
        <option selected>Total floor</option>
		<option>1</option>
        <option>2</option>
		<option>3</option>
		<option>4</option>
		<option>5</option>
      </select>
    </div>
	<div class="form-group col-md-3">
      <select id="inputState" class="form-control">
        <option selected>Open side</option>
		<option>1</option>
        <option>2</option>
		<option>3</option>
		<option>4</option>
		<option>5</option>
      </select>
    </div>
	<div class="form-group col-md-3">
      <select id="inputState" class="form-control">
        <option selected>Facing</option>
		<option>East</option>
        <option>West</option>
		<option>North</option>
		<option>South</option>
      </select>
    </div>
	</div>
</div>


                                            



                                        </div>
                                         </div> <input type="button" name="previous"
                                                class="previous action-button-previous" value="Previous" /> <input
                                                type="button" name="next" class="next action-button"
                                                value="Next Step" />
                                </fieldset>
                                <fieldset>
                                    
                                    <div class="form-card">
                                        <div class="submit-property__block">
                                            <h3 class="submit-property__headline">Additional Details</h3>
											<div class="container">
<div class="form-row">
    <div class="form-group col-md-12">
      <label for="inputPassword4"style="color:black;">Over looking</label>
	</div>
</div>
	<div class="form-row">
    <div class="form-group col-md-3">
    <div class="form-check">
      <input class="form-check-input" type="checkbox" id="gridCheck">
      <label class="form-check-label" for="gridCheck">
        Corner Property
      </label>
    </div>
  </div>
  <div class="form-group col-md-3">
    <div class="form-check">
      <input class="form-check-input" type="checkbox" id="gridCheck">
      <label class="form-check-label" for="gridCheck">
        Road
      </label>
    </div>
  </div>
  <div class="form-group col-md-3">
    <div class="form-check">
      <input class="form-check-input" type="checkbox" id="gridCheck">
      <label class="form-check-label" for="gridCheck">
        Park
      </label>
    </div>
  </div>
    </div>
	</div>
	<div class="container">
<div class="form-row">
    <div class="form-group col-md-12">
      <label for="inputPassword4"style="color:black;">Owner Type</label>
	</div>
</div>
	<div class="form-row">
    <div class="form-group col-md-3">
    <div class="form-check">
      <input class="form-check-input" type="checkbox" id="gridCheck">
      <label class="form-check-label" for="gridCheck">
        Free hold
      </label>
    </div>
  </div>
  <div class="form-group col-md-3">
    <div class="form-check">
      <input class="form-check-input" type="checkbox" id="gridCheck">
      <label class="form-check-label" for="gridCheck">
        Power Of Attomey
      </label>
    </div>
  </div>
  <div class="form-group col-md-3">
    <div class="form-check">
      <input class="form-check-input" type="checkbox" id="gridCheck">
      <label class="form-check-label" for="gridCheck">
        Co-operative Society
      </label>
    </div>
  </div>
    </div>
	</div>
	<div class="container">
<div class="form-row">
    <div class="form-group col-md-12">
      <label for="inputState">Flooring Type</label>
	</div>
</div>
<div class="form-row">
	<div class="form-group col-md-3">
      <select id="inputState" class="form-control">
        <option selected>Living Room</option>
		<option>Ceramic Porciline Tiles</option>
        <option>Vitrified Tiles</option>
		<option>Anti Skid Tiles</option>
		<option>Marble granet Tiles</option>
		<option>Wooden Flooring</option>
		<option>Laminated Wooden Flooring</option>
		<option>Wood Finish Vinvi Flooring</option>

      </select>
    </div>
	<div class="form-group col-md-3">
      <select id="inputState" class="form-control">
        <option selected>Kitchen</option>
		<option>Ceramic Porciline Tiles</option>
        <option>Vitrified Tiles</option>
		<option>Anti Skid Tiles</option>
		<option>Marble granet Tiles</option>
		<option>Wooden Flooring</option>
		<option>Laminated Wooden Flooring</option>
		<option>Wood Finish Vinvi Flooring</option>

      </select>
    </div>
	<div class="form-group col-md-3">
      <select id="inputState" class="form-control">
        <option selected>Bath Room</option>
		<option>Ceramic Porciline Tiles</option>
        <option>Vitrified Tiles</option>
		<option>Anti Skid Tiles</option>
		<option>Marble granet Tiles</option>
		<option>Wooden Flooring</option>
		<option>Laminated Wooden Flooring</option>
		<option>Wood Finish Vinvi Flooring</option>

      </select>
    </div>
	</div>
	<div class="form-row">
	<div class="form-group col-md-3">
      <select id="inputState" class="form-control">
        <option selected>Bed Room</option>
		<option>Ceramic Porciline Tiles</option>
        <option>Vitrified Tiles</option>
		<option>Anti Skid Tiles</option>
		<option>Marble granet Tiles</option>
		<option>Wooden Flooring</option>
		<option>Laminated Wooden Flooring</option>
		<option>Wood Finish Vinvi Flooring</option>

      </select>
    </div>
	<div class="form-group col-md-3">
      <select id="inputState" class="form-control">
        <option selected>Balcony</option>
		<option>Ceramic Porciline Tiles</option>
        <option>Vitrified Tiles</option>
		<option>Anti Skid Tiles</option>
		<option>Marble granet Tiles</option>
		<option>Wooden Flooring</option>
		<option>Laminated Wooden Flooring</option>
		<option>Wood Finish Vinvi Flooring</option>

      </select>
    </div>
	<div class="form-group col-md-3">
      <select id="inputState" class="form-control">
        <option selected>Other Room</option>
		<option>Ceramic Porciline Tiles</option>
        <option>Vitrified Tiles</option>
		<option>Anti Skid Tiles</option>
		<option>Marble granet Tiles</option>
		<option>Wooden Flooring</option>
		<option>Laminated Wooden Flooring</option>
		<option>Wood Finish Vinvi Flooring</option>

      </select>
    </div>
	</div>
</div>	

                                            <!-- .row -->
                                        </div><!-- .submit-property__block -->

                                        <div class="container">
                                        <div class="submit-property__block">
                                            <div class="form-row">
    <div class="form-group col-md-12">
      <label for="inputState">Flooring Type</label>
	</div>
</div>
                                            <div class="submit-property__group">
                                                <div class="submit-property__upload submit-property__upload-multi2"style="
    width: 833px;
">
                                                    <div id="plan-img-area"></div>
                                                    <input id="plan-img" type="file" multiple>
                                                    <div class="submit-property__upload-inner">
                                                        <span class="ion-ios-plus-outline submit-property__icon"></span>
                                                        <span class="submit-property__upload-desc">Drop all
                                                            images
                                                            here or click to upload</span>
                                                    </div>
                                                </div><!-- .submit-proeprty__upload -->
                                            </div><!-- .submit-property__group -->
                                        </div><!-- .submit-property__block -->
                                    </div>
									<div class="container">
<div class="form-row">
    <div class="form-group col-md-12">
      <label for="inputPassword4"style="color:black;">Posted By:</label>
	</div>
</div>
	<div class="form-row">
    <div class="form-group col-md-3">
    <div class="form-check">
      <input class="form-check-input" type="checkbox" id="gridCheck">
      <label class="form-check-label" for="gridCheck">
        Owner
      </label>
    </div>
  </div>
  <div class="form-group col-md-3">
    <div class="form-check">
      <input class="form-check-input" type="checkbox" id="gridCheck">
      <label class="form-check-label" for="gridCheck">
        Agent
      </label>
    </div>
  </div>
  <div class="form-group col-md-3">
    <div class="form-check">
      <input class="form-check-input" type="checkbox" id="gridCheck">
      <label class="form-check-label" for="gridCheck">
        Builder
      </label>
    </div>
  </div>
    </div>
	</div> 
									</div><input type="button" name="previous"
                                                class="previous action-button-previous" value="Previous" /> <input
                                                type="button" name="next" class="next action-button"
                                                value="Next Step" />
                                </fieldset>
								<fieldset>
                                    <div class="form-card">

                                        <div class="submit-property__block">

                                            <div class="submit-property__block">
                                                <h3 class="submit-property__headline">Location</h3>
                                                <div class="submit-property__group">
                                                    <div id="submit-property-map"></div>
                                                </div><!-- .submit-property__group -->

                                                <div class="submit-property__group">
                                                    <label for="property-map-address"
                                                        class="submit-property__label">Google Map Address *</label>
                                                    <input type="text" class="submit-property__field"
                                                        id="roperty-map-address" required>
                                                </div><!-- .submit-property__group -->

                                                <div class="submit-property__group">
                                                    <label for="property-address"
                                                        class="submit-property__label">Friendly Address</label>
                                                    <input type="text" class="submit-property__field"
                                                        id="property-address">
                                                </div><!-- .submit-property__group -->

                                                <div class="row">
                                                    <div class="col-md-4">
                                                        <div class="submit-property__group">
                                                            <label for="property-longtitude"
                                                                class="submit-property__label">Longtitude</label>
                                                            <input type="text" class="submit-property__field"
                                                                id="property-longtitude">
                                                        </div><!-- .submit-property__group -->
                                                    </div><!-- .col -->

                                                    <div class="col-md-4">
                                                        <div class="submit-property__group">
                                                            <label for="property-latitude"
                                                                class="submit-property__label">Latitude</label>
                                                            <input type="text" class="submit-property__field"
                                                                id="property__latitude">
                                                        </div><!-- .submit-property__group -->
                                                    </div><!-- .col -->

                                                    <div class="col-md-4">
                                                        <div class="submit-property__group">
                                                            <label for="property-region"
                                                                class="submit-property__label">Region</label>
                                                            <select id="property-region" class="ht-field">
                                                                <option value="AZ">Arizona</option>
                                                                <option value="CO">Colorado</option>
                                                                <option value="ID">Idaho</option>
                                                                <option value="MT">Montana</option>
                                                                <option value="NE">Nebraska</option>
                                                                <option value="NM">New Mexico</option>
                                                                <option value="ND">North Dakota</option>
                                                                <option value="UT">Utah</option>
                                                                <option value="WY">Wyoming</option>
                                                                <option value="CT">Connecticut</option>
                                                                <option value="DE">Delaware</option>
                                                                <option value="FL">Florida</option>
                                                                <option value="GA">Georgia</option>
                                                                <option value="IN">Indiana</option>
                                                                <option value="ME">Maine</option>
                                                                <option value="MD">Maryland</option>
                                                                <option value="MA">Massachusetts</option>
                                                                <option value="MI">Michigan</option>
                                                                <option value="NH">New Hampshire</option>
                                                                <option value="NJ">New Jersey</option>
                                                                <option value="NY">New York</option>
                                                                <option value="NC">North Carolina</option>
                                                                <option value="OH">Ohio</option>
                                                                <option value="PA">Pennsylvania</option>
                                                                <option value="RI">Rhode Island</option>
                                                                <option value="SC">South Carolina</option>
                                                                <option value="VT">Vermont</option>
                                                                <option value="VA">Virginia</option>
                                                                <option value="WV">West Virginia</option>
                                                            </select>
                                                        </div><!-- .submit-property__group -->
                                                    </div><!-- .col -->
                                                </div><!-- .row -->
                                            </div><!-- .submit-property__block -->



                                        </div>
                                        </div> <input type="button" name="previous" class="previous action-button-previous"
                                        value="Previous" /> <input type="button" name="make_payment"
                                        class="next action-button" value="Confirm" />
                                </fieldset>
								
                              
  <fieldset>
                                    <div class="form-card">
                                        <h2 class="fs-title text-center">Success !</h2> <br><br>
                                        <div class="row justify-content-center">
                                            <div class="col-3"> <img
                                                    src="https://img.icons8.com/color/96/000000/ok--v2.png"
                                                    class="fit-image"> </div>
                                        </div> <br><br>
                                        <div class="row justify-content-center">
                                            <div class="col-7 text-center">
                                                <h5>You Have Successfully Signed Up</h5>
                                            </div>
                                        </div>
                                    </div>
                                </fieldset>



                              
				   </div>
                </div>
            </div>
        </div>
    </div>
</body>
<script>
    $(document).ready(function () {

        var current_fs, next_fs, previous_fs; //fieldsets
        var opacity;

        $(".next").click(function () {

            current_fs = $(this).parent();
            next_fs = $(this).parent().next();

            //Add Class Active
            $("#progressbar li").eq($("fieldset").index(next_fs)).addClass("active");

            //show the next fieldset
            next_fs.show();
            //hide the current fieldset with style
            current_fs.animate({ opacity: 0 }, {
                step: function (now) {
                    // for making fielset appear animation
                    opacity = 1 - now;

                    current_fs.css({
                        'display': 'none',
                        'position': 'relative'
                    });
                    next_fs.css({ 'opacity': opacity });
                },
                duration: 600
            });
        });

        $(".previous").click(function () {

            current_fs = $(this).parent();
            previous_fs = $(this).parent().prev();

            //Remove class active
            $("#progressbar li").eq($("fieldset").index(current_fs)).removeClass("active");

            //show the previous fieldset
            previous_fs.show();

            //hide the current fieldset with style
            current_fs.animate({ opacity: 0 }, {
                step: function (now) {
                    // for making fielset appear animation
                    opacity = 1 - now;

                    current_fs.css({
                        'display': 'none',
                        'position': 'relative'
                    });
                    previous_fs.css({ 'opacity': opacity });
                },
                duration: 600
            });
        });

        $('.radio-group .radio').click(function () {
            $(this).parent().find('.radio').removeClass('selected');
            $(this).addClass('selected');
        });

        $(".submit").click(function () {
            return false;
        })

    });
</script>
    </div>
	<script src="css2/js/plugins.js"></script>
<script src="css2/js/jquery-1.12.4.min.js"></script>

<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBDyCxHyc8z9gMA5IlipXpt0c33Ajzqix4"></script>
<script src="css2/js/infobox.js"></script>
<script src="css2/js/custom.js"></script>

    <script src="assets/js/feather-icons/feather.min.js"></script>
    <script src="assets/vendors/perfect-scrollbar/perfect-scrollbar.min.js"></script>
    <script src="assets/js/app.js"></script>
    
    <script src="assets/js/main.js"></script>
	
	
	
	
	<script src="assets/js/feather-icons/feather.min.js"></script>
    <script src="assets/vendors/perfect-scrollbar/perfect-scrollbar.min.js"></script>
    <script src="assets/js/app.js"></script>
    
    <script src="assets/vendors/quill/quill.min.js"></script>
    <script src="assets/js/pages/form-editor.js"></script>
</body>
</html>
